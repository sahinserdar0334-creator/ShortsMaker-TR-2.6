@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.shortsmaker.app.pipeline

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** يحوّل المقطع إلى 9:16 (1080x1920) مع كتابة عربية متزامنة. يجب استدعاؤه من الـ Main thread. */
class ClipRenderer(private val ctx: Context) {

    /**
     * [startSec]/[endSec]: نطاق القص داخل الملف. للملف المقصوص مسبقاً نمرّر 0 و null.
     * [cues] أزمنتها نسبية لبداية المقطع.
     */
    suspend fun render(src: File, startSec: Double, endSec: Double?, cues: List<Cue>, output: File) {
        val clipping = MediaItem.ClippingConfiguration.Builder().apply {
            setStartPositionMs((startSec * 1000).toLong())
            if (endSec != null) setEndPositionMs((endSec * 1000).toLong())
        }.build()
        val mi = MediaItem.Builder().setUri(Uri.fromFile(src)).setClippingConfiguration(clipping).build()

        val overlay = object : TextOverlay() {
            private val settings = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.45f).build()
            override fun getText(presentationTimeUs: Long): SpannableString {
                val t = presentationTimeUs / 1_000_000.0
                val cue = cues.firstOrNull { t >= it.start && t < it.end } ?: return SpannableString(" ")
                val w = wrap(cue.text, 24)
                val s = SpannableString(w)
                val n = w.length
                s.setSpan(ForegroundColorSpan(Color.WHITE), 0, n, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                s.setSpan(BackgroundColorSpan(Color.argb(175, 0, 0, 0)), 0, n, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                s.setSpan(AbsoluteSizeSpan(60, false), 0, n, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                s.setSpan(StyleSpan(Typeface.BOLD), 0, n, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                return s
            }
            override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings
        }

        val videoEffects = ImmutableList.builder<Effect>().apply {
            add(Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            if (cues.isNotEmpty()) add(OverlayEffect(ImmutableList.of<TextureOverlay>(overlay)))
        }.build()
        val item = EditedMediaItem.Builder(mi).setEffects(Effects(emptyList(), videoEffects)).build()

        suspendCancellableCoroutine<Unit> { cont ->
            val transformer = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Unit)
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                }).build()
            cont.invokeOnCancellation { transformer.cancel() }
            transformer.start(item, output.absolutePath)
        }
    }

    private fun wrap(text: String, maxChars: Int): String {
        val lines = mutableListOf<String>()
        var cur = StringBuilder()
        for (w in text.split(" ")) {
            if (cur.isNotEmpty() && cur.length + 1 + w.length > maxChars) { lines += cur.toString(); cur = StringBuilder() }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(w)
        }
        if (cur.isNotEmpty()) lines += cur.toString()
        return lines.joinToString("\n")
    }
}
