# إعداد النشر التلقائي

كل المفاتيح تُدخل داخل التطبيق (تبويب «النشر التلقائي») وتُخزَّن مشفّرة (AES-256 + Android Keystore). لا تضعها في الكود ولا ترفعها إلى GitHub.

## 1) YouTube Shorts
1. افتح https://console.cloud.google.com وأنشئ مشروعاً، ثم فعّل **YouTube Data API v3** من APIs & Services ← Library.
2. APIs & Services ← **OAuth consent screen**: النوع External، أضف بريدك ضمن Test users، وأضف النطاق `.../auth/youtube`.
3. مهم: اضغط **Publish app** لينتقل من Testing إلى In production. في وضع Testing تنتهي صلاحية الربط بعد 7 أيام. التطبيق غير الموثَّق يظهر تحذيراً عند الموافقة، وهذا طبيعي لحسابك الشخصي.
4. Credentials ← Create credentials ← **OAuth client ID** ← النوع **TVs and Limited Input devices**. انسخ Client ID وClient Secret إلى التطبيق.
5. في التطبيق: فعّل YouTube، الصق المفتاحين، اضغط «ربط حساب يوتيوب»، افتح الصفحة، أدخل الرمز الظاهر ووافق.

قيود يجب معرفتها:
- مشاريع API المنشأة بعد 28 يوليو 2020 وغير المدقَّقة تُقفل فيها الفيديوهات المرفوعة على **خاص (private)** حتى تجتاز مراجعة Google (نموذج YouTube API Services Audit). لذلك الافتراضي في التطبيق «خاص»، ويمكنك نشرها يدوياً من YouTube Studio.
- الحصة اليومية الافتراضية 10,000 وحدة، والرفع الواحد يكلف 1,600 وحدة، أي نحو 6 مقاطع في اليوم.

## 2) TikTok
1. سجّل في https://developers.tiktok.com وأنشئ تطبيقاً، وأضف المنتجين **Login Kit** و**Content Posting API**، وفعّل النطاقات `user.info.basic` و`video.upload` و`video.publish`.
2. سجّل **Redirect URI** بعنوان https تملكه (لا يلزم أن تعمل الصفحة، فسننسخ الكود من شريط العنوان).
3. أضف حسابك كمستخدم تجريبي (Target user) للتطبيق وهو في وضع التطوير.
4. في التطبيق: الصق Client Key وSecret وRedirect URI ← «فتح صفحة دخول تيك توك» ← وافق ← انسخ `code` من الرابط (أو الرابط كاملاً) والصقه ← «تبادل الكود». الكود صالح دقائق قليلة فقط.
5. بعدها يجدد التطبيق الـ access token تلقائياً.

قيود:
- التطبيقات غير المدقَّقة لا تستطيع **النشر المباشر** إلا بخصوصية «أنا فقط»، وقد يرفضه تيك توك أصلاً. الوضع الافتراضي في التطبيق هو **مسودة**: يصل الفيديو إلى صندوق إشعارات تيك توك فتفتحه وتنشره بنفسك. النشر المباشر الكامل يتطلب اجتياز تدقيق تيك توك.

## 3) Instagram Reels
1. الحساب يجب أن يكون **Business أو Creator** ومربوطاً بصفحة فيسبوك.
2. في https://developers.facebook.com أنشئ تطبيقاً (نوع Business)، وأضف **Facebook Login for Business** (مطلوب للرفع المباشر) ومنتج Instagram.
3. من Graph API Explorer أنشئ User token بالأذونات: `instagram_basic` و`instagram_content_publish` و`pages_show_list` و`pages_read_engagement`.
4. حوّله إلى token طويل (60 يوماً): `GET /oauth/access_token?grant_type=fb_exchange_token&client_id=APP_ID&client_secret=APP_SECRET&fb_exchange_token=TOKEN`.
5. اعرف User ID: `GET /me/accounts` ثم `GET /{page-id}?fields=instagram_business_account` والمعرّف الناتج هو `id` داخله.
6. الصق User ID والـ token في التطبيق. جدّد الـ token كل 60 يوماً يدوياً.

ما دام حسابك مديراً/مختبِراً للتطبيق وهو في وضع التطوير، لا تحتاج App Review. رقم إصدار Graph API في `Uploaders.kt` (الثابت V)، غيّره إن انتهت صلاحيته.

## أوقات النشر
- «فوراً»: يبدأ الرفع بعد حفظ كل مقطع مباشرة.
- «جدولة»: تحدد أوقاتاً يومية مثل `12:00,18:00,21:00`، ويُسنَد لكل مقطع جديد أقرب وقت فارغ بعد آخر مقطع مجدول (مقطع واحد لكل وقت).
- التنفيذ عبر WorkManager بفحص كل 15 دقيقة، فقد يتأخر النشر دقائق عن الموعد، وأكثر إن كان الهاتف في وضع توفير الطاقة. أوقف تحسين البطارية لتطبيق Shorts Maker من إعدادات الهاتف.
- الطابور يبقى بعد إغلاق التطبيق أو إعادة تشغيل الهاتف. كل منصة تُجرَّب 3 مرات ثم تُعلَّم فاشلة وتظهر في السجل.
