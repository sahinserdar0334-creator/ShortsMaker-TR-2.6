plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.shortsmaker.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shortsmaker.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 12
        versionName = "2.6-TR2"
    }

    // مفتاح توقيع ثابت: يجعل كل نسخة جديدة تُثبَّت فوق القديمة دون مسح الإعدادات والبيانات
    signingConfigs {
        create("release") {
            storeFile = file("release.keystore")
            storePassword = "shortsmaker123"
            keyAlias = "shortsmaker"
            keyPassword = "shortsmaker123"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        jniLibs { useLegacyPackaging = true } // مطلوب لتشغيل yt-dlp و ffmpeg من مجلد المكتبات
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.core:core-ktx:1.15.0")

    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06") // تخزين مشفّر للمفاتيح

    // yt-dlp + ffmpeg: سحب الفيديوهات من القنوات وقص المقاطع
    val ytdl = "0.17.2"
    implementation("io.github.junkfood02.youtubedl-android:library:$ytdl")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$ytdl")

    // Media3 Transformer: قص + اقتصاص 9:16 + كتابة الترجمة على الفيديو
    val media3 = "1.5.1"
    implementation("androidx.media3:media3-transformer:$media3")
    implementation("androidx.media3:media3-effect:$media3")
    implementation("androidx.media3:media3-common:$media3")
}
