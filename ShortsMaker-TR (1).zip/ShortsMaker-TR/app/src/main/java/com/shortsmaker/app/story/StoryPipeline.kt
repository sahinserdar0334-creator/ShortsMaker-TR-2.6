package com.shortsmaker.app.story

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.shortsmaker.app.data.AppLog
import com.shortsmaker.app.data.Settings
import com.shortsmaker.app.data.StepState
import com.shortsmaker.app.data.UploadQueue
import com.shortsmaker.app.pipeline.Cue
import com.shortsmaker.app.pipeline.Saver
import com.shortsmaker.app.publish.PublishScheduler
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.coroutineContext

/** زر واحد: كتابة قصة أصلية ← صوت ← خلفيات ← فيديو بالكتابة ← حفظ ← (نشر)، جزءاً جزءاً. */
class StoryPipeline(private val ctx: Context) {
    private val settings = Settings(ctx)
    private val renderer = StoryRenderer(ctx)

    suspend fun run() {
        val key = settings.geminiKey
        require(key.isNotBlank()) { "Önce Gemini API anahtarını gir" }

        // ── 1) كتابة القصة ──
        val s0 = AppLog.addSteps(listOf("Hikâye, karakterler ve diyaloglar yazılıyor"))
        AppLog.step(s0, StepState.RUNNING)
        AppLog.add("✍ Gemini yeni, özgün bir hikâye yazıyor...")
        val story = try {
            withContext(Dispatchers.IO) {
                StoryWriter.write(key, settings.model, settings.storyPremise, settings.storyStyle, settings.storyParts)
            }
        } catch (e: Exception) {
            AppLog.step(s0, StepState.FAILED); throw e
        }
        AppLog.step(s0, StepState.DONE)
        AppLog.story.value = format(story)
        AppLog.add("✔ Hikâye: «${story.title}» — ${story.parts.size} bölüm, ${story.characters.size} karakter")

        val first = AppLog.addSteps(story.parts.flatMap {
            listOf("Bölüm ${it.n}: ses üretimi", "Bölüm ${it.n}: arka planlar ve video birleştirme", "Bölüm ${it.n}: kaydetme ve yayın")
        })

        val work = File(ctx.cacheDir, "story_${System.currentTimeMillis()}").apply { mkdirs() }
        val stamp = System.currentTimeMillis() / 1000
        var done = 0
        try {
            for ((i, part) in story.parts.withIndex()) {
                coroutineContext.ensureActive()
                val sA = first + i * 3; val sB = sA + 1; val sC = sA + 2
                var cur = sA
                try {
                    // ── 2) الصوت ──
                    AppLog.step(sA, StepState.RUNNING)
                    AppLog.add("🎙 Bölüm ${part.n}: ses üretimi (${settings.ttsVoice})...")
                    val wav = File(work, "p${part.n}.wav")
                    withContext(Dispatchers.IO) {
                        Tts.synthesize(key, settings.ttsModel, settings.ttsVoice, settings.ttsStyle, part.fullText, wav)
                    }
                    val audioSec = Tts.wavDurationSec(wav)
                    AppLog.step(sA, StepState.DONE)
                    AppLog.add("   ✔ Ses süresi ${audioSec.toInt()} saniye")

                    // ── 3) الخلفيات + الفيديو ──
                    cur = sB
                    AppLog.step(sB, StepState.RUNNING)
                    AppLog.add("🎨 Bölüm ${part.n}: ${part.scenes.size} sahne çiziliyor ve video birleştiriliyor...")
                    val (scenes, cues) = buildScenes(story, part, audioSec, work)
                    val out = File(work, "part${part.n}.mp4")
                    withContext(Dispatchers.Main) { renderer.render(scenes, wav, if (settings.captions) cues else emptyList(), out) }
                    AppLog.step(sB, StepState.DONE)

                    // ── 4) الحفظ والنشر ──
                    cur = sC
                    AppLog.step(sC, StepState.RUNNING)
                    val path = withContext(Dispatchers.IO) { Saver.saveToGallery(ctx, out, "story_${stamp}_p${part.n}") }
                    AppLog.add("💾 Bölüm ${part.n}: şuraya kaydedildi: $path")
                    queueForPublishing(story, part, out)
                    AppLog.step(sC, StepState.DONE)
                    done++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    AppLog.step(cur, StepState.FAILED)
                    AppLog.add("   ✗ Bölüm ${part.n} başarısız: ${e.message}")
                }
            }
        } finally {
            work.deleteRecursively()
        }
        AppLog.add("✔ Bitti. Kaydedilen bölümler: $done / ${story.parts.size} (Movies/ShortsMaker)")
    }

    /** يوزّع مدة الصوت على المشاهد والكتابة بنسبة عدد الأحرف، ويولّد صورة لكل مشهد من Pollinations. */
    private suspend fun buildScenes(story: Story, part: Part, audioSec: Double, work: File): Pair<List<SceneImage>, List<Cue>> {
        val totalSec = audioSec + 0.6
        val totalMs = (totalSec * 1000).toLong()
        val totalChars = part.scenes.sumOf { it.text.length }.toDouble().coerceAtLeast(1.0)
        val seed = kotlin.math.abs(story.title.hashCode())
        val images = mutableListOf<SceneImage>()
        val cues = mutableListOf<Cue>()
        var tSec = 0.0
        var usedMs = 0L
        for ((k, sc) in part.scenes.withIndex()) {
            coroutineContext.ensureActive()
            val dSec = totalSec * sc.text.length / totalChars
            val ms = if (k == part.scenes.lastIndex) totalMs - usedMs else (dSec * 1000).toLong()
            usedMs += ms

            val f = File(work, "p${part.n}_s$k.png")
            AppLog.add("   🖼 Sahne ${k + 1}/${part.scenes.size}: görsel üretiliyor...")
            val got = PollinationsImages.fetch(imagePrompt(story, sc), seed, f)
            if (!got) AppLog.add("      ⚠ Görsel üretilemedi, yedek arka plan kullanıldı")
            withContext(Dispatchers.IO) {
                val base = if (got) BitmapFactory.decodeFile(f.path) else null
                val bmp = Backgrounds.compose(base, sc.mood, part.n * 100 + k, story.title, "Bölüm ${part.n}")
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bmp.recycle()
            }
            images += SceneImage(f, ms)

            val ph = phrases(sc.text)
            val chars = ph.sumOf { it.length }.toDouble().coerceAtLeast(1.0)
            var ct = tSec
            val span = ms / 1000.0 - 0.1
            for (p in ph) {
                val d = span * p.length / chars
                cues += Cue(ct, ct + d, p)
                ct += d
            }
            tSec += ms / 1000.0
        }
        return images to cues
    }

    /** وصف الصورة = أسلوب فني ثابت + وصف المشهد + الوصف البصري الثابت للشخصيات الظاهرة فيه (للاتساق). */
    private fun imagePrompt(story: Story, sc: Scene): String {
        val present = story.characters.filter { c ->
            sc.characters.any { n -> n.equals(c.name, true) || c.name.contains(n, true) || n.contains(c.name, true) }
        }
        val who = present.joinToString("; ") { "${it.name}: ${it.visual}" }
        return buildString {
            append(story.artStyle).append(", ").append(sc.visualPrompt)
            if (who.isNotBlank()) append(", characters: ").append(who)
            append(", vertical 9:16 composition, cinematic, no text, no letters, no watermark")
        }.take(900)
    }

    private fun phrases(text: String): List<String> {
        val raw = text.split(Regex("(?<=[.!?؟،,:؛…\\n])\\s*")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = mutableListOf<String>()
        for (r in raw) r.split(" ").filter { it.isNotEmpty() }.chunked(7).forEach { out += it.joinToString(" ") }
        return out
    }

    private fun format(s: Story): String = buildString {
        appendLine("«${s.title}»")
        if (s.logline.isNotBlank()) appendLine(s.logline)
        appendLine()
        appendLine("Karakterler:")
        s.characters.forEach { appendLine("• ${it.name}: ${it.role}") }
        s.parts.forEach { p ->
            appendLine()
            appendLine("── Bölüm ${p.n}: ${p.title} ──")
            appendLine(p.fullText)
        }
    }

    private fun queueForPublishing(story: Story, part: Part, clip: File) {
        val platforms = settings.enabledPlatforms()
        val mode = settings.publishMode
        if (mode == "off" || platforms.isEmpty()) return

        val now = System.currentTimeMillis()
        val at = if (mode == "schedule")
            UploadQueue.nextSlot(settings.scheduleTimes, maxOf(now, UploadQueue.lastScheduled(ctx)))
        else now
        val title = "${story.title} — Bölüm ${part.n}"
        val desc = "${part.teaser}\n\n${story.hashtags} ${settings.hashtags}\n\n🤖 Yapay zekâ ile üretilmiş özgün hikâye"
        UploadQueue.add(ctx, clip, title, desc, platforms, at)
        if (mode == "schedule") {
            PublishScheduler.ensurePeriodic(ctx)
            AppLog.add("   ⏰ Zamanlandı: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(java.util.Date(at))}")
        } else {
            PublishScheduler.kickNow(ctx)
        }
    }
}
