package com.shortsmaker.app.story

import android.graphics.*
import kotlin.random.Random

/** يرسم خلفيات سينمائية عمودية 1080x1920 برمجياً حسب مزاج المشهد (بلا حقوق ولا اتصال بالإنترنت). */
object Backgrounds {
    const val W = 1080
    const val H = 1920

    private data class Palette(val top: Int, val bottom: Int, val accent: Int)

    private fun palette(mood: String) = when (mood) {
        "horror" -> Palette(0xFF1A0000.toInt(), 0xFF050005.toInt(), 0xFF8B0000.toInt())
        "tension" -> Palette(0xFF0B1F14.toInt(), 0xFF020805.toInt(), 0xFF2E8B57.toInt())
        "sad" -> Palette(0xFF1F2A3A.toInt(), 0xFF0A0F18.toInt(), 0xFF6C8EAD.toInt())
        "adventure" -> Palette(0xFF3A1C4A.toInt(), 0xFF0F0A1F.toInt(), 0xFFFF9F43.toInt())
        "calm" -> Palette(0xFF14323F.toInt(), 0xFF07141A.toInt(), 0xFF7FD1C7.toInt())
        else -> Palette(0xFF121A3A.toInt(), 0xFF04050F.toInt(), 0xFF6C5CE7.toInt()) // mystery
    }

    fun render(mood: String, seed: Int, title: String, partLabel: String): Bitmap {
        val p = palette(mood)
        val rnd = Random(seed)
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        paint.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), p.top, p.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), paint)

        // نجوم / غبار
        paint.shader = null
        repeat(90) {
            paint.color = Color.argb(rnd.nextInt(40, 160), 255, 255, 255)
            c.drawCircle(rnd.nextFloat() * W, rnd.nextFloat() * H * 0.7f, rnd.nextFloat() * 3f + 1f, paint)
        }
        // قمر أو توهج رئيسي
        val cx = W * (0.25f + rnd.nextFloat() * 0.5f)
        val cy = H * (0.18f + rnd.nextFloat() * 0.15f)
        paint.shader = RadialGradient(cx, cy, 380f, intArrayOf(withAlpha(p.accent, 150), withAlpha(p.accent, 0)), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, 380f, paint)
        paint.shader = null
        paint.color = Color.argb(230, 245, 245, 235)
        c.drawCircle(cx, cy, 95f, paint)

        // ضباب بطبقات
        repeat(7) {
            val fx = rnd.nextFloat() * W
            val fy = H * (0.45f + rnd.nextFloat() * 0.5f)
            val r = 260f + rnd.nextFloat() * 320f
            paint.shader = RadialGradient(fx, fy, r, intArrayOf(withAlpha(p.accent, 55), 0), null, Shader.TileMode.CLAMP)
            c.drawCircle(fx, fy, r, paint)
        }
        paint.shader = null

        // صفوف أشكال داكنة (أفق مباني/جبال)
        for (layer in 0 until 3) {
            val base = H * (0.62f + layer * 0.1f)
            paint.color = Color.argb(255, 4 + layer * 3, 4 + layer * 3, 8 + layer * 4)
            val path = Path().apply {
                moveTo(0f, H.toFloat())
                var x = 0f
                lineTo(0f, base)
                while (x < W) {
                    val w = 60f + rnd.nextFloat() * 140f
                    val h = base - rnd.nextFloat() * (260f - layer * 60f)
                    lineTo(x, h); lineTo(x + w, h)
                    x += w
                }
                lineTo(W.toFloat(), H.toFloat()); close()
            }
            c.drawPath(path, paint)
        }

        // تعتيم الأطراف
        paint.shader = RadialGradient(W / 2f, H / 2f, H * 0.75f, intArrayOf(0, Color.argb(190, 0, 0, 0)), floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), paint)
        paint.shader = null

        // عنوان القصة ورقم الجزء أعلى الشاشة
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 64f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
            setShadowLayer(8f, 0f, 3f, Color.BLACK)
        }
        c.drawText(ellipsize(title, tp, W - 160f), W / 2f, 190f, tp)
        tp.textSize = 52f; tp.color = p.accent
        c.drawText(partLabel, W / 2f, 270f, tp)
        return bmp
    }

    /**
     * يجهّز صورة المشهد النهائية: إن وُجدت صورة مولَّدة تُقصّ لتملأ 1080x1920 ويُضاف عليها العنوان،
     * وإلا تُرسم خلفية بديلة برمجياً.
     */
    fun compose(base: Bitmap?, mood: String, seed: Int, title: String, partLabel: String): Bitmap {
        if (base == null) return render(mood, seed, title, partLabel)
        val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val scale = maxOf(W.toFloat() / base.width, H.toFloat() / base.height)
        val dw = base.width * scale; val dh = base.height * scale
        c.drawBitmap(base, null, RectF((W - dw) / 2, (H - dh) / 2, (W + dw) / 2, (H + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        base.recycle()
        val band = Paint().apply { shader = LinearGradient(0f, 0f, 0f, 380f, Color.argb(190, 0, 0, 0), 0, Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, W.toFloat(), 380f, band)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 64f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
            setShadowLayer(8f, 0f, 3f, Color.BLACK)
        }
        c.drawText(ellipsize(title, tp, W - 160f), W / 2f, 190f, tp)
        tp.textSize = 52f; tp.color = palette(mood).accent
        c.drawText(partLabel, W / 2f, 270f, tp)
        return out
    }

    private fun ellipsize(s: String, p: Paint, maxW: Float): String {
        if (p.measureText(s) <= maxW) return s
        var t = s
        while (t.length > 3 && p.measureText("$t…") > maxW) t = t.dropLast(1)
        return "$t…"
    }

    private fun withAlpha(color: Int, a: Int) = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))
}
