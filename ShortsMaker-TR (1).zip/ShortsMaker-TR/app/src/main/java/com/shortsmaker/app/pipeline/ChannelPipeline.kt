package com.shortsmaker.app.pipeline

import android.content.Context
import com.shortsmaker.app.data.AppLog
import com.shortsmaker.app.data.Report
import com.shortsmaker.app.data.Settings
import com.shortsmaker.app.data.StepState
import com.shortsmaker.app.data.UploadQueue
import com.shortsmaker.app.publish.PublishScheduler
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.coroutineContext

/** زر واحد: أحدث فيديوهات القنوات ← ترجمة/تفريغ ← اختيار أفضل اللحظات ← قص 9:16 + كتابة عربية ← حفظ ← (نشر). */
class ChannelPipeline(private val ctx: Context) {
    private companion object { const val SEARCH_DEPTH = 40 }
    private val settings = Settings(ctx)
    private val renderer = ClipRenderer(ctx)

    suspend fun run() {
        val key = settings.geminiKey
        require(key.isNotBlank()) { "Önce Gemini API anahtarını gir" }
        val specs = settings.channelSpecs()
        require(specs.isNotEmpty()) { "En az bir kanal ekle (her satıra bir kanal)" }

        // ── 1) تجهيز الأدوات والبحث عن الفيديوهات ──
        val s0 = AppLog.addSteps(listOf("İndirme aracı hazırlanıyor", "Kanalların en yeni videoları aranıyor"))
        AppLog.step(s0, StepState.RUNNING)
        AppLog.add("⚙ yt-dlp hazırlanıyor (ilk seferde bir dakika sürebilir)...")
        try { Yt.init(ctx) } catch (e: Exception) { AppLog.step(s0, StepState.FAILED); throw e }
        AppLog.add("   ⬆ yt-dlp güncelleme: ${Yt.update(ctx)}")
        AppLog.step(s0, StepState.DONE)

        AppLog.step(s0 + 1, StepState.RUNNING)
        val todo = mutableListOf<Video>()
        val targets = HashMap<String, Set<String>>() // معرّف الفيديو ← منصات النشر الخاصة بقناته
        for (spec in specs) {
            val ch = spec.handle
            coroutineContext.ensureActive()
            try {
                // نفحص آخر 40 فيديو (الأحدث أولاً) ونأخذ أحدث غير المعالَج منها، فإن كانت الأحدث معالَجة نرجع للأقدم تلقائياً
                val latest = Yt.latest(ch, SEARCH_DEPTH)
                val unseen = latest.filter { !settings.isDone(it.id) }
                val fresh = unseen.take(settings.videosPerChannel)
                val older = fresh.count { v -> latest.indexOf(v) >= settings.videosPerChannel }
                AppLog.add("📡 $ch: işlenecek ${fresh.size} video (son ${latest.size} tarandı, daha önce işlenen ${latest.size - unseen.size})" +
                    if (older > 0) " — bunların $older tanesi son ${settings.videosPerChannel} videodan eski" else "")
                todo += fresh
                fresh.forEach { targets[it.id] = spec.platforms }
                Report.add(ctx, "channel_ok", ch, "işlenecek ${fresh.size} video (${latest.size} tarandı, daha önce işlenen ${latest.size - unseen.size})")
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                AppLog.add("   ✗ ${e.message}")
                Report.add(ctx, "channel_err", ch, e.message?.take(150) ?: "Hata")
            }
        }
        if (todo.isEmpty()) {
            AppLog.step(s0 + 1, StepState.DONE)
            AppLog.add("✔ İşlenmemiş yeni video yok. (Yeniden işlemek için Klipler sekmesinden kaydı silebilirsin)")
            return
        }
        AppLog.step(s0 + 1, StepState.DONE)

        val first = AppLog.addSteps(todo.flatMap { listOf("«${it.title.take(34)}»: metin çıkarma ve an seçimi", "«${it.title.take(34)}»: kesme, birleştirme ve kaydetme") })
        val work = File(ctx.cacheDir, "clips_${System.currentTimeMillis()}").apply { mkdirs() }
        val stamp = System.currentTimeMillis() / 1000
        var saved = 0
        try {
            for ((vi, v) in todo.withIndex()) {
                coroutineContext.ensureActive()
                val sA = first + vi * 2; val sB = sA + 1
                var cur = sA
                val vdir = File(work, "v$vi").apply { mkdirs() }
                try {
                    // ── 2) النص + اختيار اللحظات ──
                    AppLog.step(sA, StepState.RUNNING)
                    AppLog.add("🎬 ${v.title}")
                    val tr = Transcripts.fetch(key, settings.model, v.id, vdir)
                    AppLog.add("   📝 Metin: ${tr.segs.size} parça (${tr.lang}) — ${(tr.duration / 60).toInt()} dk")
                    val minS = settings.clipMinSec
                    val maxS = maxOf(settings.clipMaxSec, minS + 5)
                    val picks = ClipSelector.pick(key, settings.model, tr, v.title, settings.clipsPerVideo, minS, maxS)
                    if (picks.isEmpty()) error("Yapay zekâ uygun an bulamadı")
                    AppLog.add("   ✂ ${picks.size} an seçti")
                    AppLog.step(sA, StepState.DONE)

                    // ── 3) كل لحظة: تنزيل المقطع ← كتابة عربية ← تركيب ← حفظ ← نشر ──
                    cur = sB
                    AppLog.step(sB, StepState.RUNNING)
                    for ((k, p) in picks.withIndex()) {
                        coroutineContext.ensureActive()
                        val label = "${k + 1}/${picks.size}"
                        try {
                            AppLog.add("   ⬇ Klip $label: «${p.title}» (${p.end.minus(p.start).toInt()} sn)")
                            val (src, isCut) = Yt.clip(v.id, p.start, p.end, File(work, "dl_${vi}_$k"))
                            val cues = if (settings.captions) ClipSelector.cues(key, settings.model, tr, p.start, p.end) else emptyList()
                            AppLog.add(if (settings.captions) "   🔤 Türkçe altyazı: ${cues.size} satır" else "   🔇 Altyazı kapalı (videoya yazı eklenmiyor)")
                            val out = File(work, "out_${vi}_$k.mp4")
                            withContext(Dispatchers.Main) {
                                if (isCut) renderer.render(src, 0.0, null, cues, out)
                                else renderer.render(src, p.start, p.end, cues, out)
                            }
                            val path = withContext(Dispatchers.IO) { Saver.saveToGallery(ctx, out, "clip_${stamp}_${vi + 1}_${k + 1}") }
                            AppLog.add("   💾 Kaydedildi: $path")
                            Report.add(ctx, "clip_ok", p.title)
                            enqueue(v, p, out, targets[v.id] ?: emptySet())
                            saved++
                            File(work, "dl_${vi}_$k").deleteRecursively()
                        } catch (e: CancellationException) { throw e } catch (e: Exception) {
                            AppLog.add("   ✗ Klip $label başarısız: ${e.message?.take(160)}")
                            Report.add(ctx, "clip_fail", p.title, e.message?.take(150) ?: "Hata")
                        }
                    }
                    settings.markDone(v.id)
                    AppLog.step(sB, StepState.DONE)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    AppLog.step(cur, StepState.FAILED)
                    AppLog.add("   ✗ Bu video başarısız: ${e.message?.take(160)}")
                    Report.add(ctx, "video_fail", v.title, e.message?.take(150) ?: "Hata")
                } finally {
                    vdir.deleteRecursively()
                }
            }
        } finally {
            work.deleteRecursively()
        }
        AppLog.add("✔ Bitti. Kaydedilen klipler: $saved (Movies/ShortsMaker)")
    }

    private fun enqueue(v: Video, p: ClipPick, clip: File, only: Set<String>) {
        val key = mapOf("youtube" to "yt", "tiktok" to "tt", "instagram" to "ig")
        val enabled = settings.enabledPlatforms()
        // قناة محدّدة المنصات: نأخذ المتقاطع مع المنصات المفعّلة. بدون تحديد: كل المفعّلة.
        val platforms = if (only.isEmpty()) enabled else enabled.filter { key[it] in only }
        val mode = settings.publishMode
        if (mode == "off" || enabled.isEmpty()) return
        if (platforms.isEmpty()) {
            AppLog.add("   ⚠ Bu kanalın platformları (${only.joinToString("/")}) Yayın sekmesinde etkin değil, yayınlanmayacak")
            return
        }

        val now = System.currentTimeMillis()
        val at = if (mode == "schedule")
            UploadQueue.nextSlot(settings.scheduleTimes, maxOf(now, UploadQueue.lastScheduled(ctx)))
        else now
        val tags = Hashtags.merge(p.tags, settings.hashtags)
        val desc = "${p.hook}\n\n$tags\n\n🎬 Kaynak: ${v.title}"
        UploadQueue.add(ctx, clip, p.title, desc, platforms, at)
        if (mode == "schedule") {
            PublishScheduler.ensurePeriodic(ctx)
            AppLog.add("   ⏰ Zamanlandı: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(java.util.Date(at))}")
        } else {
            PublishScheduler.kickNow(ctx)
        }
    }
}
