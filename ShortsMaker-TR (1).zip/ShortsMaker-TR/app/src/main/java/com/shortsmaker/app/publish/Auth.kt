package com.shortsmaker.app.publish

import com.shortsmaker.app.data.Creds
import okhttp3.FormBody
import okhttp3.Request
import org.json.JSONObject
import java.net.URLDecoder

data class DeviceCode(val deviceCode: String, val userCode: String, val url: String, val interval: Int, val expiresIn: Int)

/** ربط يوتيوب عبر OAuth "Giriş kısıtlı cihaz": تدخل رمزاً قصيراً في google.com/device بلا حاجة لـ redirect. */
object YouTubeAuth {
    private const val SCOPE = "https://www.googleapis.com/auth/youtube"
    @Volatile private var cached: Pair<String, Long>? = null

    fun requestDeviceCode(c: Creds): DeviceCode {
        val j = Net.json(
            Request.Builder().url("https://oauth2.googleapis.com/device/code")
                .post(FormBody.Builder().add("client_id", c.ytClientId).add("scope", SCOPE).build()).build()
        )
        return DeviceCode(
            j.getString("device_code"), j.getString("user_code"),
            j.optString("verification_url", "https://www.google.com/device"),
            j.optInt("interval", 5), j.optInt("expires_in", 1800),
        )
    }

    /** ينتظر موافقتك ثم يحفظ refresh token. يعيد true عند النجاح. */
    fun pollForToken(c: Creds, d: DeviceCode): Boolean {
        val deadline = System.currentTimeMillis() + d.expiresIn * 1000L
        var interval = d.interval
        while (System.currentTimeMillis() < deadline) {
            Thread.sleep(interval * 1000L)
            val req = Request.Builder().url("https://oauth2.googleapis.com/token").post(
                FormBody.Builder().add("client_id", c.ytClientId).add("client_secret", c.ytClientSecret)
                    .add("device_code", d.deviceCode)
                    .add("grant_type", "urn:ietf:params:oauth:grant-type:device_code").build()
            ).build()
            try {
                Net.client.newCall(req).execute().use { r ->
                    val j = JSONObject(r.body?.string().orEmpty())
                    if (r.isSuccessful) {
                        c.ytRefresh = j.getString("refresh_token")
                        cached = j.getString("access_token") to (System.currentTimeMillis() + j.getLong("expires_in") * 1000)
                        return true
                    }
                    when (j.optString("error")) {
                        "authorization_pending" -> {}
                        "slow_down" -> interval += 5
                        else -> error(j.optString("error_description", j.optString("error")))
                    }
                }
            } catch (e: java.io.IOException) {
                // انقطاع شبكة مؤقت (التطبيق في الخلفية أو توفير بيانات): نتجاهله ونعيد المحاولة
            }
        }
        return false
    }

    fun accessToken(c: Creds): String {
        cached?.let { if (it.second > System.currentTimeMillis() + 60_000) return it.first }
        require(c.ytRefresh.isNotBlank()) { "YouTube hesabı bağlı değil" }
        val j = Net.json(
            Request.Builder().url("https://oauth2.googleapis.com/token").post(
                FormBody.Builder().add("client_id", c.ytClientId).add("client_secret", c.ytClientSecret)
                    .add("refresh_token", c.ytRefresh).add("grant_type", "refresh_token").build()
            ).build()
        )
        val t = j.getString("access_token")
        cached = t to (System.currentTimeMillis() + j.getLong("expires_in") * 1000)
        return t
    }
}

/** تيك توك: تسجيل الدخول في المتصفح ثم لصق الكود في التطبيق لتبادله بـ Access/Refresh token. */
object TikTokAuth {
    fun authorizeUrl(c: Creds): String {
        val redirect = java.net.URLEncoder.encode(c.ttRedirect, "UTF-8")
        return "https://www.tiktok.com/v2/auth/authorize/?client_key=${c.ttClientKey}" +
            "&scope=user.info.basic,video.upload,video.publish&response_type=code" +
            "&redirect_uri=$redirect&state=shortsmaker"
    }

    /** يقبل الكود وحده أو الرابط كاملاً الذي ظهر في المتصفح بعد الموافقة. */
    fun exchangeCode(c: Creds, pasted: String) {
        var code = pasted.trim()
        Regex("[?&]code=([^&]+)").find(code)?.let { code = it.groupValues[1] }
        code = URLDecoder.decode(code, "UTF-8")
        val j = Net.json(
            Request.Builder().url("https://open.tiktokapis.com/v2/oauth/token/").post(
                FormBody.Builder().add("client_key", c.ttClientKey).add("client_secret", c.ttClientSecret)
                    .add("code", code).add("grant_type", "authorization_code")
                    .add("redirect_uri", c.ttRedirect).build()
            ).header("Content-Type", "application/x-www-form-urlencoded").build()
        )
        store(c, j)
    }

    private fun store(c: Creds, j: JSONObject) {
        if (!j.has("access_token")) error(j.optString("error_description", j.toString().take(300)))
        c.ttAccess = j.getString("access_token")
        c.ttRefresh = j.getString("refresh_token")
        c.ttExpiresAt = (System.currentTimeMillis() + j.getLong("expires_in") * 1000).toString()
    }

    fun accessToken(c: Creds): String {
        require(c.ttAccess.isNotBlank()) { "TikTok hesabı bağlı değil" }
        val exp = c.ttExpiresAt.toLongOrNull() ?: 0L
        if (exp > System.currentTimeMillis() + 120_000) return c.ttAccess
        val j = Net.json(
            Request.Builder().url("https://open.tiktokapis.com/v2/oauth/token/").post(
                FormBody.Builder().add("client_key", c.ttClientKey).add("client_secret", c.ttClientSecret)
                    .add("grant_type", "refresh_token").add("refresh_token", c.ttRefresh).build()
            ).header("Content-Type", "application/x-www-form-urlencoded").build()
        )
        store(c, j)
        return c.ttAccess
    }
}
