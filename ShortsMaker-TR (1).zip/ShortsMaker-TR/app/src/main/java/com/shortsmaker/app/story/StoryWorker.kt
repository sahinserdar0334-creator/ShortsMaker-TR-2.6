package com.shortsmaker.app.story

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.shortsmaker.app.App
import com.shortsmaker.app.data.AppLog

class StoryWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        AppLog.setRunning(true)
        return try {
            runCatching { setForeground(foreground()) }
            StoryPipeline(ctx).run()
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            AppLog.add("⏹ Durduruldu")
            throw e
        } catch (e: Exception) {
            AppLog.add("✗ Hata: ${e.message}")
            Result.failure()
        } finally {
            AppLog.setRunning(false)
        }
    }

    private fun foreground(): ForegroundInfo {
        val n = NotificationCompat.Builder(ctx, App.CHANNEL_ID)
            .setContentTitle("Shorts Maker").setContentText("Hikâye oluşturuluyor ve videolar hazırlanıyor...")
            .setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel, "Durdur",
                androidx.work.WorkManager.getInstance(ctx).createCancelPendingIntent(id),
            ).build()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ForegroundInfo(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(3, n)
    }
}
