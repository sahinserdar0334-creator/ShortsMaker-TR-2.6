package com.shortsmaker.app.story

import com.shortsmaker.app.data.AppLog
import kotlinx.coroutines.delay
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** يطلب من Gemini كتابة قصة أصلية بالكامل: عنوان، شخصيات، أجزاء بنهايات مشوقة، ومشاهد بمزاج لكل مشهد. */
object StoryWriter {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).callTimeout(150, TimeUnit.SECONDS).readTimeout(150, TimeUnit.SECONDS).build()

    suspend fun write(apiKey: String, model: String, premise: String, style: String, parts: Int): Story {
        val prompt = """
You are an award-winning Turkish storyteller writing a serialized short-video story for TikTok / Reels / YouTube Shorts.

Write a COMPLETELY ORIGINAL story. Do not copy, retell, or imitate any existing book, film, series, game, video, or creator's story. Do not use real people or real brands.

Premise / genre hint: ${premise.ifBlank { "invent a fresh, gripping premise yourself" }}
Style: $style

Structure:
- Exactly $parts parts. Each part is 130 to 170 words in total (about 55 seconds when read aloud).
- Part 1 opens with a strong hook in its first sentence.
- Every part except the last ends on a cliffhanger. The last part resolves the story with a twist.
- 2 to 4 named characters with distinct personalities.
- Mix narration and short dialogue lines, written like: Ahmet dedi ki: "..." so that ONE narrator can read everything aloud.
- Short sentences, easy to read aloud. Use plain spoken everyday Turkish as requested in the style for dialogue and light narration.
- No markdown, no emojis, no stage directions.
- Visual consistency: give the story one "art_style" (English, one line, e.g. "cinematic digital painting, dark moody lighting, desert night"). For EVERY character write a FIXED English "visual" description (age, build, face, hair/beard, clothes, one distinguishing mark) that will be reused word for word in every image.
- For every scene write an English "visual_prompt": what the image shows (setting, action, camera angle, lighting). Do NOT describe character appearance in it (the app adds it). List the names of the characters that appear in the scene in "characters" (use the exact names from the characters list; empty if none).
- Split each part into 3 to 5 scenes. Each scene contains the exact text to be spoken and a mood chosen from: mystery, horror, tension, sad, adventure, calm. The part text is the scenes joined in order.

Return ONLY JSON in this exact shape:
{"title":"...","logline":"one sentence","art_style":"...","characters":[{"name":"...","role":"...","visual":"..."}],
"parts":[{"n":1,"title":"...","teaser":"one short hook sentence for the caption","scenes":[{"text":"...","mood":"mystery","visual_prompt":"...","characters":["..."]}]}],
"hashtags":["#...","#..."]}
title, logline, characters.name/role, parts.title, teaser, scenes.text and hashtags must be in Turkish. art_style, visual and visual_prompt must be in English.
""".trimIndent()

        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 1.0))
            .toString()

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toRequestBody("application/json".toMediaType())).build()

        // محاولات متعددة: انقطاع الشبكة المؤقت أو ازدحام Gemini لا يوقف العملية من أول مرة
        var raw = ""
        var lastErr: Exception? = null
        for (attempt in 1..3) {
            try {
                raw = http.newCall(req).await().use { r ->
                    val s = r.body?.string().orEmpty()
                    if (r.code == 429 || r.code >= 500) throw java.io.IOException("Gemini HTTP ${r.code}")
                    if (!r.isSuccessful) error("Gemini HTTP ${r.code}: ${s.take(300)}")
                    s
                }
                lastErr = null
                break
            } catch (e: java.io.IOException) {
                lastErr = e
                AppLog.add("   ⚠ Gemini'den yanıt gelmedi (deneme $attempt/3): ${e.message}")
                if (attempt < 3) delay(5_000L * attempt)
            }
        }
        lastErr?.let {
            error("3 denemeden sonra Gemini'ye ulaşılamadı (${it.message}). İnterneti kontrol et ve üretim sırasında uygulamada kal.")
        }
        val text = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val j = JSONObject(text.trim().removePrefix("```json").removeSuffix("```").trim())

        val chars = mutableListOf<Character>()
        j.optJSONArray("characters")?.let { a ->
            for (i in 0 until a.length()) a.getJSONObject(i).let { chars += Character(it.optString("name"), it.optString("role"), it.optString("visual")) }
        }
        val partsOut = mutableListOf<Part>()
        val pa = j.getJSONArray("parts")
        for (i in 0 until pa.length()) {
            val p = pa.getJSONObject(i)
            val scenes = mutableListOf<Scene>()
            val sa = p.getJSONArray("scenes")
            for (k in 0 until sa.length()) {
                val sc = sa.getJSONObject(k)
                val t = sc.optString("text").trim()
                val names = mutableListOf<String>()
                sc.optJSONArray("characters")?.let { na -> for (q in 0 until na.length()) names += na.optString(q) }
                if (t.isNotEmpty()) scenes += Scene(t, sc.optString("mood", "mystery"), sc.optString("visual_prompt"), names)
            }
            if (scenes.isNotEmpty()) partsOut += Part(p.optInt("n", i + 1), p.optString("title"), scenes, p.optString("teaser"))
        }
        if (partsOut.isEmpty()) error("Gemini hiç bölüm üretmedi")
        val tags = j.optJSONArray("hashtags")?.let { a -> (0 until a.length()).joinToString(" ") { a.getString(it) } } ?: ""
        return Story(j.optString("title", "Hikâye"), j.optString("logline"), j.optString("art_style", "cinematic digital painting, dark moody lighting"), chars, partsOut, tags)
    }
}
