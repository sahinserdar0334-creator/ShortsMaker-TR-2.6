package com.shortsmaker.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.shortsmaker.app.data.Settings
import com.shortsmaker.app.publish.PublishScheduler

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Shorts Maker", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        if (Settings(this).publishMode == "schedule") PublishScheduler.ensurePeriodic(this)
    }

    companion object {
        const val CHANNEL_ID = "shorts_maker"
    }
}
