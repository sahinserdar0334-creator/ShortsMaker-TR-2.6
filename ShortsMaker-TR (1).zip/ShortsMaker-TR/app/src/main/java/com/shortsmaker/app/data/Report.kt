package com.shortsmaker.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * تقرير دائم (يبقى بعد إغلاق التطبيق): ماذا سُحب، كم مقطع صُنع، ماذا نُشر وأين، وما الأخطاء.
 * نخزّن أحداثاً مختصرة في ملف ونبني منها نصاً مقروءاً عند الطلب.
 */
object Report {
    private const val MAX_EVENTS = 800
    private val lock = Any()

    private class Ev(val t: Long, val k: String, val a: String, val b: String, val c: String)

    private fun file(ctx: Context) = File(ctx.filesDir, "report.json")

    private fun load(ctx: Context): MutableList<Ev> = synchronized(lock) {
        try {
            val f = file(ctx)
            if (!f.exists()) return mutableListOf()
            val arr = JSONArray(f.readText())
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Ev(o.optLong("t"), o.optString("k"), o.optString("a"), o.optString("b"), o.optString("c"))
            }
        } catch (e: Exception) { mutableListOf() }
    }

    fun add(ctx: Context, kind: String, a: String = "", b: String = "", c: String = "") {
        synchronized(lock) {
            try {
                val list = load(ctx)
                list += Ev(System.currentTimeMillis(), kind, a.take(120), b.take(200), c.take(200))
                val arr = JSONArray()
                list.takeLast(MAX_EVENTS).forEach {
                    arr.put(JSONObject().put("t", it.t).put("k", it.k).put("a", it.a).put("b", it.b).put("c", it.c))
                }
                file(ctx).writeText(arr.toString())
            } catch (_: Exception) { /* التقرير لا يجب أن يعطّل العمل */ }
        }
    }

    fun clear(ctx: Context) = synchronized(lock) { file(ctx).delete() }

    private fun plat(p: String) = when (p) { "youtube" -> "YouTube"; "instagram" -> "Instagram"; "tiktok" -> "TikTok"; else -> p }
    private fun time(t: Long) = SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(t))

    fun build(ctx: Context, running: Boolean): String {
        val ev = load(ctx)
        if (ev.isEmpty()) return "Henüz rapor yok. Önce çekmeyi veya yayını çalıştır."
        val sb = StringBuilder()

        // ── آخر تشغيل للسحب ──
        val start = ev.indexOfLast { it.k == "run_start" }
        sb.appendLine("📋 Son çalıştırma raporu")
        if (start < 0) {
            sb.appendLine("Henüz çalıştırma kaydedilmedi.")
        } else {
            val run = ev.subList(start, ev.size)
            val end = run.firstOrNull { it.k == "run_end" || it.k == "run_stop" }
            sb.append("Başladı: ").append(time(run[0].t))
            when {
                end?.k == "run_end" -> sb.appendLine(" — bitti: ${time(end.t)} ✔")
                end?.k == "run_stop" -> sb.appendLine(" — elle durduruldu: ${time(end.t)} ⏹")
                running -> sb.appendLine(" — hâlâ çalışıyor ⏳")
                else -> sb.appendLine(" — tamamlanmadı (durdu veya kesildi) ⚠")
            }
            sb.appendLine()
            sb.appendLine("Kanallar:")
            run.filter { it.k == "channel_ok" || it.k == "channel_err" }.forEach {
                sb.appendLine(if (it.k == "channel_ok") " • ${it.a}: ${it.b}" else " • ${it.a}: ✗ ${it.b}")
            }
            val clipsOk = run.count { it.k == "clip_ok" }
            val clipsFail = run.filter { it.k == "clip_fail" }
            val vidFail = run.filter { it.k == "video_fail" }
            sb.appendLine()
            sb.appendLine("Kaydedilen klipler: $clipsOk")
            sb.appendLine("Başarısız klipler: ${clipsFail.size}")
            sb.appendLine("Başarısız videolar: ${vidFail.size}")
            (vidFail + clipsFail).take(8).forEach { sb.appendLine(" ✗ ${it.a}: ${it.b}") }
            run.filter { it.k == "error" }.forEach { sb.appendLine(" ✗ Hata: ${it.a}") }
        }

        // ── النشر (آخر 24 ساعة) ──
        val since = System.currentTimeMillis() - 24L * 3600_000
        val pubs = ev.filter { (it.k == "pub_ok" || it.k == "pub_fail") && it.t >= since }
        sb.appendLine()
        sb.appendLine("🚀 Yayın (son 24 saat)")
        if (pubs.isEmpty()) sb.appendLine("Yayın yok.")
        else {
            for (p in listOf("youtube", "instagram", "tiktok")) {
                val ok = pubs.count { it.k == "pub_ok" && it.a == p }
                val bad = pubs.count { it.k == "pub_fail" && it.a == p }
                if (ok + bad > 0) sb.appendLine(" ${plat(p)}: ✔ $ok  ✗ $bad")
            }
            val fails = pubs.filter { it.k == "pub_fail" }.takeLast(8)
            if (fails.isNotEmpty()) {
                sb.appendLine()
                sb.appendLine("Yayın hataları:")
                fails.forEach { sb.appendLine(" ✗ [${plat(it.a)}] ${it.b.take(40)}: ${it.c}") }
            }
            val oks = pubs.filter { it.k == "pub_ok" }.takeLast(6)
            if (oks.isNotEmpty()) {
                sb.appendLine()
                sb.appendLine("Son yayınlananlar:")
                oks.forEach { sb.appendLine(" ✔ [${plat(it.a)}] ${time(it.t)} ${it.b.take(40)}") }
            }
        }
        sb.appendLine()
        sb.appendLine("Şu an kuyrukta: ${UploadQueue.pendingCount(ctx)}")
        return sb.toString().trim()
    }
}
