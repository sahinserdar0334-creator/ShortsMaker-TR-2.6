package com.shortsmaker.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.graphics.graphicsLayer
import com.shortsmaker.app.data.ChannelSpec
import com.shortsmaker.app.data.Report
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.shortsmaker.app.data.AppLog
import com.shortsmaker.app.data.Creds
import com.shortsmaker.app.data.Settings
import com.shortsmaker.app.data.StepState
import com.shortsmaker.app.data.UploadQueue
import com.shortsmaker.app.pipeline.ClipsWorker
import com.shortsmaker.app.publish.DeviceCode
import com.shortsmaker.app.publish.PublishScheduler
import com.shortsmaker.app.publish.TikTokAuth
import com.shortsmaker.app.publish.YouTubeAuth
import com.shortsmaker.app.story.StoryWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// ───────────────────────── الألوان والثيم ─────────────────────────

private val Violet = Color(0xFF8B5CF6)
private val Pink = Color(0xFFFF3D9A)
private val Orange = Color(0xFFFF8A3D)
private val Cyan = Color(0xFF22E5FF)
private val Lime = Color(0xFF5DFFA0)
private val Danger = Color(0xFFFF4D6D)

private val AppColors = darkColorScheme(
    primary = Cyan, onPrimary = Color(0xFF00212A),
    secondary = Violet, tertiary = Pink,
    background = Color(0xFF070718), onBackground = Color(0xFFEDEDFF),
    surface = Color(0xFF12122B), onSurface = Color(0xFFEDEDFF),
    surfaceVariant = Color(0xFF1E1E45), onSurfaceVariant = Color(0xFFB8B8E8),
    outline = Color(0xFF5A5A9C), error = Danger, onError = Color.White,
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = AppColors, shapes = Shapes(extraSmall = RoundedCornerShape(14.dp), small = RoundedCornerShape(16.dp))) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Root() }
            }
        }
    }
}

@Composable
private fun Root() {
    var tab by remember { mutableIntStateOf(0) }
    val logs by AppLog.lines.collectAsStateWithLifecycle()
    CompositionLocalProvider(LocalContentColor provides Color(0xFFEDEDFF)) {
    Box(Modifier.fillMaxSize()) {
        CosmicBackground()
        Column(Modifier.fillMaxSize()) {
            Header()
            NeonTabs(tab) { tab = it }
            AnimatedContent(
                targetState = tab,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                transitionSpec = {
                    // RTL: التبويب الأعلى رقماً يقع يساراً، فيدخل من اليسار
                    val dir = if (targetState > initialState) -1 else 1
                    (slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { dir * it / 3 } + fadeIn(tween(380)))
                        .togetherWith(slideOutHorizontally(tween(300, easing = FastOutSlowInEasing)) { -dir * it / 3 } + fadeOut(tween(200)))
                },
                label = "tabs",
            ) { t ->
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 2.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                ) {
                    when (t) {
                        0 -> ClipsTab()
                        1 -> NeonCard("🚀 Otomatik Yayın") { PublishTab() }
                        else -> StoryTab()
                    }
                }
            }
            LogPanel(logs)
        }
    }
    }
}

// ───────────────────────── عناصر التصميم ─────────────────────────

/** خلفية كونية متحركة: نجوم تتلألأ وهالات نيون تتحرك ببطء. */
@Composable
private fun CosmicBackground() {
    val t = rememberInfiniteTransition(label = "bg")
    val phase by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(22000, easing = LinearEasing)), label = "phase",
    )
    val stars = remember { val r = kotlin.random.Random(7); List(130) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) } }
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF040411), Color(0xFF0D0629), Color(0xFF1B0836))))
        val w = size.width; val h = size.height
        val a = (phase * 2 * Math.PI).toFloat()
        fun blob(cx: Float, cy: Float, r: Float, c: Color) = drawCircle(
            Brush.radialGradient(listOf(c.copy(alpha = 0.33f), Color.Transparent), center = Offset(cx, cy), radius = r),
            radius = r, center = Offset(cx, cy),
        )
        blob(w * 0.15f + 70f * sin(a), h * 0.12f + 40f * cos(a), w * 0.75f, Violet)
        blob(w * 0.95f + 50f * cos(a), h * 0.50f + 70f * sin(a), w * 0.65f, Cyan)
        blob(w * 0.25f + 50f * sin(a + 1f), h * 0.95f, w * 0.75f, Pink)
        stars.forEach { (x, y, sz) ->
            val tw = 0.3f + 0.7f * abs(sin(a * 2 + sz * 6))
            drawCircle(Color.White.copy(alpha = tw * 0.85f), radius = 1.2f + sz * 2.2f, center = Offset(x * w, y * h))
        }
    }
}

@Composable
private fun Header() {
    Column(
        Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 0.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "SHORTS MAKER",
            style = TextStyle(
                brush = Brush.horizontalGradient(listOf(Cyan, Violet, Pink, Orange)),
                fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp,
                shadow = Shadow(color = Violet.copy(alpha = 0.9f), blurRadius = 26f),
            ),
        )
        Text("Uzun videodan yayınlanan Shorts'a", color = Color(0xFFB8B8E8), fontSize = 11.sp)
    }
}

@Composable
private fun NeonTabs(selected: Int, onSelect: (Int) -> Unit) {
    val labels = listOf("📡  Klipler", "🚀  Yayın", "✨  Hikaye")
    val shape = RoundedCornerShape(16.dp)
    BoxWithConstraints(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)
            .clip(shape).background(Color(0x2AFFFFFF)).padding(3.dp),
    ) {
        val w = maxWidth / labels.size
        // المؤشر ينزلق بنابض بين التبويبات (RTL: التبويب 0 على اليمين)
        val offset by animateDpAsState(w * selected, spring(dampingRatio = 0.72f, stiffness = 380f), label = "pill")
        Box(
            Modifier.offset(x = offset).align(Alignment.CenterStart).width(w).height(38.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Brush.horizontalGradient(listOf(Violet, Pink))),
        )
        Row(Modifier.fillMaxWidth()) {
            labels.forEachIndexed { i, l ->
                val sel = i == selected
                val c by animateColorAsState(if (sel) Color.White else Color(0xFFB0B0E0), tween(250), label = "c")
                val sc by animateFloatAsState(if (sel) 1.06f else 1f, spring(stiffness = 500f), label = "s")
                Box(
                    Modifier.weight(1f).height(38.dp).clip(RoundedCornerShape(13.dp)).clickable { onSelect(i) },
                    contentAlignment = Alignment.Center,
                ) { Text(l, color = c, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.scale(sc)) }
            }
        }
    }
}

@Composable
private fun NeonCard(title: String?, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    // ظهور متدرّج: تلاشي + ارتفاع بسيط عند أول عرض
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(450, easing = FastOutSlowInEasing)) }
    Column(
        Modifier.fillMaxWidth()
            .graphicsLayer { alpha = p.value; translationY = (1f - p.value) * 36f }
            .clip(shape).background(Color(0x40101035))
            .border(1.dp, Brush.linearGradient(listOf(Cyan.copy(alpha = 0.7f), Violet.copy(alpha = 0.7f), Pink.copy(alpha = 0.7f))), shape)
            .animateContentSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (title != null) Text(title, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        content()
    }
}

/** زر كبير متوهج ينبض عندما يكون جاهزاً. */
@Composable
private fun GlowButton(text: String, enabled: Boolean, brush: Brush, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val sc by t.animateFloat(
        1f, if (enabled) 1.025f else 1f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scale",
    )
    val dim = Brush.horizontalGradient(listOf(Color(0xFF2A2A48), Color(0xFF2A2A48)))
    Box(
        modifier.scale(sc).height(46.dp).clip(RoundedCornerShape(15.dp))
            .background(if (enabled) brush else dim).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (enabled) Color.White else Color(0xFF7878A0), fontWeight = FontWeight.Black, fontSize = 14.sp) }
}

@Composable
private fun StepRow(title: String, state: StepState) {
    val t = rememberInfiniteTransition(label = "dot")
    val pulse by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a")
    val (color, alpha) = when (state) {
        StepState.PENDING -> Color(0xFF55558A) to 1f
        StepState.RUNNING -> Cyan to pulse
        StepState.DONE -> Lime to 1f
        StepState.FAILED -> Danger to 1f
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(color.copy(alpha = alpha)))
        Text(
            title, fontSize = 14.sp,
            color = if (state == StepState.PENDING) Color(0xFF9090C0) else Color.White,
            fontWeight = if (state == StepState.RUNNING) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

private fun logColor(l: String): Color = when {
    l.contains("✔") -> Lime
    l.contains("✗") || l.contains("❌") -> Danger
    l.contains("⚠") -> Color(0xFFFFC53D)
    l.contains("⏳") || l.contains("⬆") || l.contains("⏰") -> Cyan
    else -> Color(0xFFB4B4DC)
}

@Composable
private fun LogPanel(logs: List<String>) {
    val state = rememberLazyListState()
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) state.animateScrollToItem(logs.lastIndex) }
    val shape = RoundedCornerShape(18.dp)
    LazyColumn(
        Modifier.fillMaxWidth().height(108.dp).padding(horizontal = 14.dp, vertical = 6.dp)
            .clip(shape).background(Color(0xDD03030C))
            .border(1.dp, Brush.horizontalGradient(listOf(Cyan.copy(alpha = 0.6f), Pink.copy(alpha = 0.6f))), shape)
            .padding(8.dp),
        state = state,
    ) {
        items(logs) { Text(it, color = logColor(it), fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
    }
}

// ───────────────────────── تبويب المقاطع (القنوات) ─────────────────────────

@Composable
private fun ClipsTab() {
    val ctx = LocalContext.current
    val settings = remember { Settings(ctx) }
    val running by AppLog.running.collectAsStateWithLifecycle()
    val steps by AppLog.steps.collectAsStateWithLifecycle()

    var key by remember { mutableStateOf(settings.geminiKey) }
    var model by remember { mutableStateOf(settings.model) }
    var channels by remember { mutableStateOf(settings.channels) }
    var perChannel by remember { mutableStateOf(settings.videosPerChannel.toString()) }
    var perVideo by remember { mutableStateOf(settings.clipsPerVideo.toString()) }
    var minSec by remember { mutableStateOf(settings.clipMinSec.toString()) }
    var maxSec by remember { mutableStateOf(settings.clipMaxSec.toString()) }
    var captions by remember { mutableStateOf(settings.captions) }

    fun save() {
        settings.geminiKey = key; settings.model = model; settings.channels = channels
        settings.videosPerChannel = perChannel.toIntOrNull() ?: 1
        settings.clipsPerVideo = perVideo.toIntOrNull() ?: 3
        settings.clipMinSec = minSec.toIntOrNull() ?: 25
        settings.clipMaxSec = maxSec.toIntOrNull() ?: 55
    }
    LaunchedEffect(key, model, channels, perChannel, perVideo, minSec, maxSec) { save() }

    fun start() {
        save()
        AppLog.clear()
        val req = OneTimeWorkRequestBuilder<ClipsWorker>().build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("clips", ExistingWorkPolicy.REPLACE, req)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { start() }

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        GlowButton(
            "🚀  Çekmeyi ve Kesmeyi Başlat", !running,
            Brush.horizontalGradient(listOf(Violet, Pink, Orange)), Modifier.weight(1.6f),
        ) {
            val perms = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            if (Build.VERSION.SDK_INT < 29) perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
            if (perms.isEmpty()) start() else permLauncher.launch(perms.toTypedArray())
        }
        GlowButton("⏹  Durdur", running, Brush.horizontalGradient(listOf(Danger, Color(0xFFB3123A))), Modifier.weight(1f)) {
            AppLog.add("⏹ Durduruluyor...")
            WorkManager.getInstance(ctx).cancelUniqueWork("clips")
        }
    }
    if (running) LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)), color = Cyan, trackColor = Color(0x33FFFFFF))
    ReportButton()

    if (steps.isNotEmpty()) {
        NeonCard("⚡ Aşamalar") { steps.forEach { StepRow(it.title, it.state) } }
    }

    NeonCard("📡 Kanallar") {
        ChannelsEditor(channels) { channels = it }
    }
    NeonCard("✂ Kesim") {
        NumField(perChannel, { perChannel = it }, "Her kanaldan kaç yeni video", Modifier.fillMaxWidth())
        NumField(perVideo, { perVideo = it }, "Her videodan kaç klip", Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumField(minSec, { minSec = it }, "En kısa süre (sn)", Modifier.weight(1f))
            NumField(maxSec, { maxSec = it }, "En uzun süre (sn)", Modifier.weight(1f))
        }
        SwitchRow("🔤 Videoya Türkçe altyazı yaz", captions) { captions = it; settings.captions = it }
    }
    NeonCard("🧠 Yapay Zekâ") {
        OutlinedTextField(
            key, { key = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API anahtarı") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true,
        )
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini modeli") }, singleLine = true)
    }
    TextButton(onClick = {
        settings.clearDone()
        AppLog.add("🧹 İşlenen videoların kaydı silindi, yeniden yeni sayılacaklar")
    }) { Text("🧹 İşlenen videoların kaydını sil", color = Color(0xFFB8B8E8)) }
    Text(
        "Uygulama daha önce işlediği videoları otomatik atlar. Çektiğin içeriği yeniden kullanma hakkın olduğundan emin ol ve kaynağı belirt.",
        fontSize = 12.sp, color = Color(0xFF9A9AD0),
    )
    Spacer(Modifier.height(8.dp))
}


// ───────────────────────── محرّر القنوات (منصة لكل قناة) ─────────────────────────

private class ChRow(handle: String, platforms: Set<String>) {
    var handle by mutableStateOf(handle)
    var platforms by mutableStateOf(platforms) // فارغة = الكل
}

@Composable
private fun ChannelsEditor(serialized: String, onChange: (String) -> Unit) {
    val rows = remember {
        mutableStateListOf<ChRow>().apply {
            serialized.lines().mapNotNull { ChannelSpec.parse(it) }.forEach { add(ChRow(it.handle, it.platforms)) }
            if (isEmpty()) add(ChRow("", emptySet()))
        }
    }
    fun push() = onChange(rows.filter { it.handle.isNotBlank() }.joinToString("\n") { ChannelSpec(it.handle.trim(), it.platforms).serialize() })

    rows.forEachIndexed { idx, r ->
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x22FFFFFF)).padding(8.dp)
                .animateContentSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    r.handle, { r.handle = it; push() }, Modifier.weight(1f), singleLine = true,
                    label = { Text("@kanal_adı veya bağlantısı", fontSize = 12.sp) },
                    textStyle = TextStyle(fontSize = 14.sp),
                )
                IconButton(onClick = { rows.removeAt(idx); if (rows.isEmpty()) rows.add(ChRow("", emptySet())); push() }) {
                    Icon(Icons.Filled.Close, "Sil", tint = Danger)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PlatChip("Hepsi", r.platforms.isEmpty(), Modifier.weight(1f)) { r.platforms = emptySet(); push() }
                PlatChip("YouTube", "yt" in r.platforms, Modifier.weight(1f)) { r.platforms = toggle(r.platforms, "yt"); push() }
                PlatChip("TikTok", "tt" in r.platforms, Modifier.weight(1f)) { r.platforms = toggle(r.platforms, "tt"); push() }
                PlatChip("Instagram", "ig" in r.platforms, Modifier.weight(1f)) { r.platforms = toggle(r.platforms, "ig"); push() }
            }
        }
    }
    TextButton(onClick = { rows.add(ChRow("", emptySet())) }) {
        Icon(Icons.Filled.Add, null, tint = Cyan, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text("Kanal ekle", color = Cyan)
    }
    Text(
        "Her kanalın kliplerinin nerede yayınlanacağını seç: yalnızca YouTube, yalnızca TikTok, yalnızca Instagram veya «Hepsi». (Platform, Yayın sekmesinde etkin ve bağlı olmalı.)",
        fontSize = 11.sp, color = Color(0xFF9A9AD0),
    )
}

private fun toggle(cur: Set<String>, p: String): Set<String> {
    val n = if (p in cur) cur - p else cur + p
    return if (n.size == ChannelSpec.ALL.size) emptySet() else n // تفعيل الثلاث = الكل
}

@Composable
private fun PlatChip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Violet else Color(0x33FFFFFF), tween(220), label = "bg")
    val sc by animateFloatAsState(if (selected) 1.04f else 1f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "sc")
    Box(
        modifier.scale(sc).height(32.dp).clip(RoundedCornerShape(10.dp)).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, color = Color.White) }
}

// ───────────────────────── تبويب القصة ─────────────────────────

@Composable
private fun StoryTab() {
    val ctx = LocalContext.current
    val settings = remember { Settings(ctx) }
    val running by AppLog.running.collectAsStateWithLifecycle()
    val steps by AppLog.steps.collectAsStateWithLifecycle()
    val story by AppLog.story.collectAsStateWithLifecycle()

    var key by remember { mutableStateOf(settings.geminiKey) }
    var model by remember { mutableStateOf(settings.model) }
    var premise by remember { mutableStateOf(settings.storyPremise) }
    var style by remember { mutableStateOf(settings.storyStyle) }
    var parts by remember { mutableStateOf(settings.storyParts.toString()) }
    var voice by remember { mutableStateOf(settings.ttsVoice) }
    var ttsModel by remember { mutableStateOf(settings.ttsModel) }
    var ttsStyle by remember { mutableStateOf(settings.ttsStyle) }

    fun save() {
        settings.geminiKey = key; settings.model = model
        settings.storyPremise = premise; settings.storyStyle = style
        settings.storyParts = parts.toIntOrNull() ?: 4
        settings.ttsVoice = voice; settings.ttsModel = ttsModel; settings.ttsStyle = ttsStyle
    }
    LaunchedEffect(key, model, premise, style, parts, voice, ttsModel, ttsStyle) { save() }

    fun start() {
        save()
        AppLog.clear()
        val req = OneTimeWorkRequestBuilder<StoryWorker>().build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("story", ExistingWorkPolicy.REPLACE, req)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { start() }

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        GlowButton(
            "🚀  Üretimi Başlat", !running,
            Brush.horizontalGradient(listOf(Violet, Pink, Orange)), Modifier.weight(1.6f),
        ) {
            val perms = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            if (Build.VERSION.SDK_INT < 29) perms += Manifest.permission.WRITE_EXTERNAL_STORAGE
            if (perms.isEmpty()) start() else permLauncher.launch(perms.toTypedArray())
        }
        GlowButton("⏹  Durdur", running, Brush.horizontalGradient(listOf(Danger, Color(0xFFB3123A))), Modifier.weight(1f)) {
            AppLog.add("⏹ Durduruluyor...")
            WorkManager.getInstance(ctx).cancelUniqueWork("story")
        }
    }
    if (running) LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)), color = Cyan, trackColor = Color(0x33FFFFFF))

    if (steps.isNotEmpty()) {
        NeonCard("⚡ Aşamalar") {
            steps.forEach { StepRow(it.title, it.state) }
        }
    }
    if (story.isNotBlank()) {
        NeonCard("📖 Yazılan hikâye") {
            Column(Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState())) {
                Text(story, fontSize = 13.sp, color = Color(0xFFE4E4FF), lineHeight = 22.sp)
            }
        }
    }

    NeonCard("🧠 Yapay Zekâ") {
        OutlinedTextField(
            key, { key = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API anahtarı") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true,
        )
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini modeli") }, singleLine = true)
    }
    NeonCard("🎭 Hikâye") {
        OutlinedTextField(
            premise, { premise = it }, Modifier.fillMaxWidth(), minLines = 2,
            label = { Text("Hikâye fikri veya türü (boş bırakırsan kendisi üretir)") },
        )
        OutlinedTextField(style, { style = it }, Modifier.fillMaxWidth(), label = { Text("Üslup ve ağız") }, singleLine = true)
        NumField(parts, { parts = it }, "Bölüm sayısı", Modifier.fillMaxWidth())
    }
    NeonCard("🎙 Ses") {
        OutlinedTextField(voice, { voice = it }, Modifier.fillMaxWidth(), label = { Text("Ses adı (Charon, Kore, Puck, Fenrir...)") }, singleLine = true)
        OutlinedTextField(ttsStyle, { ttsStyle = it }, Modifier.fillMaxWidth(), label = { Text("Okuma tarzı") })
        OutlinedTextField(ttsModel, { ttsModel = it }, Modifier.fillMaxWidth(), label = { Text("Ses modeli (TTS)") }, singleLine = true)
    }
    Text(
        "Hikâye, ses ve görseller yapay zekâ ile üretilir; TikTok ve YouTube'da yayınlarken bunu belirtme seçeneğini işaretle.",
        fontSize = 12.sp, color = Color(0xFF9A9AD0),
    )
    Spacer(Modifier.height(8.dp))
}

// ───────────────────────── تبويب النشر ─────────────────────────

@Composable
private fun PublishTab() {
    val ctx = LocalContext.current
    val settings = remember { Settings(ctx) }
    val creds = remember { Creds(ctx) }
    val scope = rememberCoroutineScope()

    var mode by remember { mutableStateOf(settings.publishMode) }
    var yt by remember { mutableStateOf(settings.pubYouTube) }
    var tt by remember { mutableStateOf(settings.pubTikTok) }
    var ig by remember { mutableStateOf(settings.pubInstagram) }
    var ytPrivacy by remember { mutableStateOf(settings.ytPrivacy) }
    var ttMode by remember { mutableStateOf(settings.ttMode) }
    var ytLinked by remember { mutableStateOf(creds.ytRefresh.isNotBlank()) }
    var ttLinked by remember { mutableStateOf(creds.ttAccess.isNotBlank()) }
    var deviceCode by remember { mutableStateOf<DeviceCode?>(null) }
    var ttPasted by remember { mutableStateOf("") }
    var pending by remember { mutableIntStateOf(UploadQueue.pendingCount(ctx)) }

    deviceCode?.let { d ->
        AlertDialog(
            onDismissRequest = { deviceCode = null },
            title = { Text("YouTube hesabını bağla") },
            text = { Text("Sayfayı aç ve kodu gir:\n\n${d.userCode}\n\n(${d.url})\n\nSonra hesabını seç ve onayla; bağlantı otomatik tamamlanır.") },
            confirmButton = {
                TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(d.url))) }) { Text("Sayfayı aç") }
            },
            dismissButton = { TextButton(onClick = { deviceCode = null }) { Text("Kapat") } },
        )
    }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Ne zaman yayınlansın?", style = MaterialTheme.typography.titleSmall)
        Choice("Otomatik yayını kapat", mode == "off") { mode = "off"; settings.publishMode = "off"; PublishScheduler.cancelPeriodic(ctx) }
        Choice("Her klip işlenir işlenmez", mode == "now") { mode = "now"; settings.publishMode = "now" }
        Choice("Belirli günlük saatlere zamanla", mode == "schedule") { mode = "schedule"; settings.publishMode = "schedule" }
        if (mode == "schedule") {
            PrefField("Günlük yayın saatleri (HH:mm, virgülle ayır)", settings.scheduleTimes, false) { settings.scheduleTimes = it }
        }
        PrefField("Etiketler (Hashtags) — yalnızca etiket kelimeleri", settings.hashtags, false) { settings.hashtags = it }
        PrefField("Açıklamada sabit satır (YouTube ve Instagram) — örn: 🔔 Yeniliklerden haberdar olmak için takip et", settings.fixedLine, false) { settings.fixedLine = it }

        HorizontalDivider()
        // ---- YouTube ----
        SwitchRow("YouTube Shorts", yt) { yt = it; settings.pubYouTube = it }
        if (yt) {
            PrefField("YouTube Client ID", creds.ytClientId, true) { creds.ytClientId = it }
            PrefField("YouTube Client Secret", creds.ytClientSecret, true) { creds.ytClientSecret = it }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Gizlilik: ")
                Choice("Özel", ytPrivacy == "private") { ytPrivacy = "private"; settings.ytPrivacy = "private" }
                Choice("Listelenmemiş", ytPrivacy == "unlisted") { ytPrivacy = "unlisted"; settings.ytPrivacy = "unlisted" }
                Choice("Herkese açık", ytPrivacy == "public") { ytPrivacy = "public"; settings.ytPrivacy = "public" }
            }
            Button(onClick = {
                scope.launch {
                    try {
                        val d = withContext(Dispatchers.IO) { YouTubeAuth.requestDeviceCode(creds) }
                        deviceCode = d
                        val ok = withContext(Dispatchers.IO) { YouTubeAuth.pollForToken(creds, d) }
                        deviceCode = null; ytLinked = ok
                        AppLog.add(if (ok) "✔ YouTube bağlandı" else "YouTube bağlama süresi doldu")
                    } catch (e: Exception) {
                        deviceCode = null; AppLog.add("✗ YouTube bağlama: ${e.message}")
                    }
                }
            }) { Text(if (ytLinked) "YouTube'u yeniden bağla (bağlı ✓)" else "YouTube hesabını bağla") }
        }

        HorizontalDivider()
        // ---- TikTok ----
        SwitchRow("TikTok", tt) { tt = it; settings.pubTikTok = it }
        if (tt) {
            PrefField("TikTok Client Key", creds.ttClientKey, true) { creds.ttClientKey = it }
            PrefField("TikTok Client Secret", creds.ttClientSecret, true) { creds.ttClientSecret = it }
            PrefField("Redirect URI (uygulamanda kayıtlı olanla aynı)", creds.ttRedirect, false) { creds.ttRedirect = it }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Choice("Taslak", ttMode == "draft") { ttMode = "draft"; settings.ttMode = "draft" }
                Choice("Doğrudan yayın", ttMode == "direct") { ttMode = "direct"; settings.ttMode = "direct" }
            }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TikTokAuth.authorizeUrl(creds))))
            }) { Text("1) TikTok giriş sayfasını aç") }
            OutlinedTextField(
                ttPasted, { ttPasted = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("2) Onaydan sonra çıkan kodu veya bağlantıyı yapıştır") },
            )
            Button(onClick = {
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { TikTokAuth.exchangeCode(creds, ttPasted) }
                        ttLinked = true; ttPasted = ""; AppLog.add("✔ TikTok bağlandı")
                    } catch (e: Exception) { AppLog.add("✗ TikTok bağlama: ${e.message}") }
                }
            }) { Text(if (ttLinked) "3) Kodu değiştir (bağlı ✓)" else "3) Kodu değiştir") }
        }

        HorizontalDivider()
        // ---- Instagram ----
        SwitchRow("Instagram Reels", ig) { ig = it; settings.pubInstagram = it }
        if (ig) {
            PrefField("Instagram User ID (Business/Creator hesabı)", creds.igUserId, false) { creds.igUserId = it }
            PrefField("Access Token (uzun ömürlü)", creds.igToken, true) { creds.igToken = it }
        }

        HorizontalDivider()
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Kuyrukta: $pending")
            OutlinedButton(onClick = {
                pending = UploadQueue.pendingCount(ctx)
                PublishScheduler.kickNow(ctx)
                AppLog.add("Kuyrukta zamanı gelenlerin yayını başladı...")
            }) { Text("Zamanı gelenleri şimdi yayınla") }
            TextButton(onClick = { pending = UploadQueue.pendingCount(ctx) }) { Text("Yenile") }
        }
        ReportButton()
    }
}


// ───────────────────────── التقرير ─────────────────────────

@Composable
private fun ReportButton() {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val running by AppLog.running.collectAsStateWithLifecycle()
    var show by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }

    OutlinedButton(
        onClick = { text = Report.build(ctx, running); show = true },
        modifier = Modifier.fillMaxWidth().height(40.dp),
        shape = RoundedCornerShape(12.dp),
    ) { Text("📋  Rapor: ne yapıldı, ne yayınlandı, hatalar", fontSize = 13.sp) }

    if (show) {
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text("Rapor") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text(text, fontSize = 12.sp, lineHeight = 18.sp)
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { text = Report.build(ctx, running) }) { Text("Yenile") }
                    TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Kopyala") }
                }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { Report.clear(ctx); text = Report.build(ctx, running) }) { Text("Temizle") }
                    TextButton(onClick = { show = false }) { Text("Kapat") }
                }
            },
        )
    }
}

// ───────────────────────── مكوّنات مساعدة ─────────────────────────

@Composable
private fun PrefField(label: String, initial: String, secret: Boolean, onSave: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    OutlinedTextField(
        v, { v = it; onSave(it) }, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
    )
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected, onClick)
        Text(label)
        Spacer(Modifier.width(8.dp))
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.titleSmall)
        Switch(checked, onChange)
    }
}

@Composable
private fun NumField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier) {
    OutlinedTextField(
        value, { onChange(it.filter(Char::isDigit)) }, modifier, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
    )
}
