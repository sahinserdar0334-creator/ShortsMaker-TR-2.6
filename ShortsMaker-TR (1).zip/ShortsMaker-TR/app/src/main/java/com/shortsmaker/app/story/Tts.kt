package com.shortsmaker.app.story

import android.util.Base64
import com.shortsmaker.app.data.AppLog
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.TimeUnit

/** تحويل النص إلى صوت عبر Gemini TTS (واجهة Interactions)، ويُخرج ملف WAV. */
/** طابور واحد لطلبات الصوت: يفرض فاصلاً زمنياً بين كل طلبين لتجنب حدود Gemini. */
object TtsQueue {
    private val mutex = Mutex()
    private var last = 0L
    const val GAP_MS = 20_000L

    suspend fun <T> run(block: suspend () -> T): T = mutex.withLock {
        val wait = last + GAP_MS - System.currentTimeMillis()
        if (wait > 0) {
            AppLog.add("      ⏳ Ses kuyruğu: sonraki istekten önce ${wait / 1000} sn bekleniyor (Gemini sınırlarını aşmamak için)")
            delay(wait)
        }
        try { block() } finally { last = System.currentTimeMillis() }
    }
}

object Tts {
    private val http = OkHttpClient.Builder()
        .callTimeout(5, TimeUnit.MINUTES).readTimeout(5, TimeUnit.MINUTES).build()

    suspend fun synthesize(apiKey: String, model: String, voice: String, style: String, text: String, out: File) {
        val textItem = JSONObject().put("type", "text").put("text", text)
        if (style.isNotBlank()) textItem.put(
            "annotations", JSONArray().put(JSONObject().put("type", "speech_metadata").put("style", style))
        )
        val body = JSONObject()
            .put("model", model)
            .put(
                "input", JSONArray().put(
                    JSONObject().put("type", "user_input").put("content", JSONArray().put(textItem))
                )
            )
            .put("response_format", JSONObject().put("type", "audio"))
            .put("generation_config", JSONObject().put("speech_config", JSONArray().put(JSONObject().put("voice", voice))))
            .toString()

        var lastErr = ""
        for (attempt in 0 until 5) {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/interactions")
                .header("x-goog-api-key", apiKey)
                .post(body.toRequestBody("application/json".toMediaType())).build()
            val result: Pair<Int, String> = TtsQueue.run {
                http.newCall(req).await().use { r -> r.code to r.body?.string().orEmpty() }
            }
            val (code, s) = result
            if (code in 200..299) {
                val b64 = findAudio(runCatching { JSONObject(s) }.getOrNull())
                    ?: error("Gemini yanıtında ses bulunamadı: ${s.take(300)}")
                writeWav(Base64.decode(b64, Base64.DEFAULT), out)
                return
            }
            lastErr = "HTTP $code: ${s.take(300)}"
            if (code != 429 && code < 500) error("TTS $lastErr")
            val wait = 15L * (attempt + 1)
            AppLog.add("      Kullanım sınırı / geçici ses hatası, ek ${wait} sn bekleniyor...")
            delay(wait * 1000)
        }
        error("Birkaç denemeden sonra ses üretilemedi: $lastErr")
    }

    /** يبحث بشكل متكرر عن كائن type=audio ويعيد حقل data (base64). */
    private fun findAudio(node: Any?): String? {
        when (node) {
            is JSONObject -> {
                if (node.optString("type") == "audio" && node.optString("data").isNotEmpty()) return node.getString("data")
                for (k in node.keys()) findAudio(node.opt(k))?.let { return it }
            }
            is JSONArray -> for (i in 0 until node.length()) findAudio(node.opt(i))?.let { return it }
        }
        return null
    }

    /** إن كان الناتج WAV كاملاً يُكتب كما هو، وإن كان PCM خاماً (24kHz, 16-bit, mono) يُغلَّف بترويسة WAV. */
    private fun writeWav(bytes: ByteArray, out: File) {
        if (bytes.size > 12 && String(bytes, 0, 4) == "RIFF") { out.writeBytes(bytes); return }
        val rate = 24000; val ch = 1; val bits = 16
        val bo = ByteArrayOutputStream()
        fun i32(v: Int) { bo.write(v and 255); bo.write(v shr 8 and 255); bo.write(v shr 16 and 255); bo.write(v shr 24 and 255) }
        fun i16(v: Int) { bo.write(v and 255); bo.write(v shr 8 and 255) }
        bo.write("RIFF".toByteArray()); i32(36 + bytes.size); bo.write("WAVE".toByteArray())
        bo.write("fmt ".toByteArray()); i32(16); i16(1); i16(ch); i32(rate); i32(rate * ch * bits / 8); i16(ch * bits / 8); i16(bits)
        bo.write("data".toByteArray()); i32(bytes.size); bo.write(bytes)
        out.writeBytes(bo.toByteArray())
    }

    /** مدة ملف WAV بالثواني (يقرأ الترويسة). */
    fun wavDurationSec(f: File): Double {
        val b = ByteArray(minOf(f.length(), 4096L).toInt())
        f.inputStream().use { ins -> var off = 0; while (off < b.size) { val n = ins.read(b, off, b.size - off); if (n < 0) break; off += n } }
        fun le32(o: Int) = (b[o].toInt() and 255) or (b[o + 1].toInt() and 255 shl 8) or (b[o + 2].toInt() and 255 shl 16) or (b[o + 3].toInt() and 255 shl 24)
        val byteRate = le32(28)
        var pos = 12
        while (pos + 8 <= b.size) {
            val id = String(b, pos, 4); val size = le32(pos + 4)
            if (id == "data") {
                val dataSize = if (size <= 0 || size > f.length()) f.length() - pos - 8 else size.toLong()
                return dataSize.toDouble() / byteRate
            }
            pos += 8 + size
        }
        return (f.length() - 44).toDouble() / byteRate
    }
}
