package com.shortsmaker.app.story

import com.shortsmaker.app.data.AppLog
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** يولّد صورة عمودية 1080x1920 لكل مشهد من Pollinations.ai (مجاني، بلا مفتاح). */
object PollinationsImages {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.MINUTES)
        .callTimeout(4, TimeUnit.MINUTES)
        .build()

    private var lastCall = 0L
    private const val GAP_MS = 3_000L

    /** يعيد true عند نجاح الحفظ في [out]، وfalse إن فشلت كل المحاولات. */
    suspend fun fetch(prompt: String, seed: Int, out: File): Boolean {
        val enc = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        val url = "https://image.pollinations.ai/prompt/$enc?width=1080&height=1920&seed=$seed&model=flux&nologo=true"
        for (attempt in 1..3) {
            val wait = lastCall + GAP_MS - System.currentTimeMillis()
            if (wait > 0) delay(wait)
            try {
                val req = Request.Builder().url(url).header("User-Agent", "ShortsMaker/1.0").build()
                val ok = http.newCall(req).await().use { r ->
                    val type = r.header("Content-Type").orEmpty()
                    val bytes = r.body?.bytes() ?: ByteArray(0)
                    if (r.isSuccessful && type.startsWith("image") && bytes.size > 5_000) {
                        out.writeBytes(bytes); true
                    } else {
                        AppLog.add("      Pollinations: HTTP ${r.code} (${bytes.size} bayt)")
                        false
                    }
                }
                lastCall = System.currentTimeMillis()
                if (ok) return true
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                lastCall = System.currentTimeMillis()
                AppLog.add("      Pollinations: ${e.message}")
            }
            if (attempt < 3) delay(8_000L * attempt)
        }
        return false
    }
}
