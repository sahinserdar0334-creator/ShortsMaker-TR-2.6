package com.shortsmaker.app.pipeline

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.shortsmaker.app.App
import com.shortsmaker.app.data.AppLog
import com.shortsmaker.app.data.Report

class ClipsWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        AppLog.setRunning(true)
        return try {
            runCatching { setForeground(foreground()) }
            Report.add(ctx, "run_start")
            ChannelPipeline(ctx).run()
            Report.add(ctx, "run_end")
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            AppLog.add("⏹ Durduruldu")
            Report.add(ctx, "run_stop")
            throw e
        } catch (e: Exception) {
            AppLog.add("✗ Hata: ${e.message}")
            Report.add(ctx, "error", e.message?.take(150) ?: "Hata")
            Report.add(ctx, "run_end")
            Result.failure()
        } finally {
            AppLog.setRunning(false)
        }
    }

    private fun foreground(): ForegroundInfo {
        val n = NotificationCompat.Builder(ctx, App.CHANNEL_ID)
            .setContentTitle("Shorts Maker").setContentText("Videolar çekiliyor ve kesiliyor...")
            .setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel, "Durdur",
                androidx.work.WorkManager.getInstance(ctx).createCancelPendingIntent(id),
            ).build()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ForegroundInfo(4, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(4, n)
    }
}
