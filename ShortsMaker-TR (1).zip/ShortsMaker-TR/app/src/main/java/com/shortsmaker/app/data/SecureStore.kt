package com.shortsmaker.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** تخزين مشفّر (AES-256) بمفتاح داخل Android Keystore؛ لا تُحفظ المفاتيح كنص عادي. */
object SecureStore {
    @Volatile private var sp: SharedPreferences? = null

    fun get(ctx: Context): SharedPreferences = sp ?: synchronized(this) {
        sp ?: create(ctx.applicationContext).also { sp = it }
    }

    private fun create(ctx: Context): SharedPreferences {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            ctx, "secure_prefs", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }
}

private class Secret(private val key: String) : ReadWriteProperty<Creds, String> {
    override fun getValue(thisRef: Creds, property: KProperty<*>): String =
        thisRef.sp.getString(key, "") ?: ""

    override fun setValue(thisRef: Creds, property: KProperty<*>, value: String) {
        thisRef.sp.edit().putString(key, value.trim()).apply()
    }
}

/** كل المفاتيح والرموز (Tokens) الحساسة. */
class Creds(ctx: Context) {
    internal val sp: SharedPreferences = SecureStore.get(ctx)

    var geminiKey by Secret("gemini_key")

    var ytClientId by Secret("yt_client_id")
    var ytClientSecret by Secret("yt_client_secret")
    var ytRefresh by Secret("yt_refresh")

    var ttClientKey by Secret("tt_client_key")
    var ttClientSecret by Secret("tt_client_secret")
    var ttRedirect by Secret("tt_redirect")
    var ttAccess by Secret("tt_access")
    var ttRefresh by Secret("tt_refresh")
    var ttExpiresAt by Secret("tt_expires_at") // ميلي ثانية كنص

    var igUserId by Secret("ig_user_id")
    var igToken by Secret("ig_token")
}
