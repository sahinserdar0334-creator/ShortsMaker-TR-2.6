@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.shortsmaker.app.story

import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.net.Uri
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import com.shortsmaker.app.pipeline.Cue
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class SceneImage(val file: File, val durationMs: Long)

/** يركّب فيديو القصة: صور الخلفية بالتتابع + الصوت + الكتابة المتزامنة. يجب استدعاؤه من الـ Main thread. */
class StoryRenderer(private val ctx: Context) {

    suspend fun render(scenes: List<SceneImage>, wav: File, cues: List<Cue>, output: File) {
        val videoItems = scenes.map { s ->
            val mi = MediaItem.Builder().setUri(Uri.fromFile(s.file)).setImageDurationMs(s.durationMs).build()
            // Ken Burns: تكبير بطيء من 100% إلى 105% على مدة المشهد
            val durUs = (s.durationMs * 1000L).coerceAtLeast(1L)
            val zoom = object : MatrixTransformation {
                override fun getMatrix(presentationTimeUs: Long): Matrix {
                    val f = (presentationTimeUs.toDouble() / durUs).coerceIn(0.0, 1.0)
                    val sc = (1.0 + 0.05 * f).toFloat()
                    return Matrix().apply { postScale(sc, sc) }
                }
            }
            EditedMediaItem.Builder(mi).setFrameRate(30)
                .setEffects(Effects(emptyList(), listOf<Effect>(zoom))).build()
        }
        val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(wav))).setRemoveVideo(true).build()

        @Suppress("DEPRECATION")
        val videoSeq = EditedMediaItemSequence(videoItems)
        @Suppress("DEPRECATION")
        val audioSeq = EditedMediaItemSequence(listOf(audioItem))

        val overlay = object : TextOverlay() {
            private val settings = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.45f).build()
            override fun getText(presentationTimeUs: Long): SpannableString {
                val t = presentationTimeUs / 1_000_000.0
                val cue = cues.firstOrNull { t >= it.start && t < it.end } ?: return SpannableString(" ")
                val w = wrap(cue.text, 24)
                val s = SpannableString(w)
                val n = w.length
                s.setSpan(ForegroundColorSpan(Color.WHITE), 0, n, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                s.setSpan(BackgroundColorSpan(Color.argb(175, 0, 0, 0)), 0, n, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                s.setSpan(AbsoluteSizeSpan(60, false), 0, n, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                s.setSpan(StyleSpan(Typeface.BOLD), 0, n, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                return s
            }
            override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings
        }

        val effects = Effects(
            emptyList(),
            ImmutableList.of<Effect>(
                Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP),
                OverlayEffect(ImmutableList.of<TextureOverlay>(overlay)),
            ),
        )
        val composition = Composition.Builder(listOf(videoSeq, audioSeq)).setEffects(effects).build()

        suspendCancellableCoroutine<Unit> { cont ->
            val transformer = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Unit)
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                }).build()
            cont.invokeOnCancellation { transformer.cancel() }
            transformer.start(composition, output.absolutePath)
        }
    }

    private fun wrap(text: String, maxChars: Int): String {
        val lines = mutableListOf<String>()
        var cur = StringBuilder()
        for (w in text.split(" ")) {
            if (cur.isNotEmpty() && cur.length + 1 + w.length > maxChars) { lines += cur.toString(); cur = StringBuilder() }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(w)
        }
        if (cur.isNotEmpty()) lines += cur.toString()
        return lines.joinToString("\n")
    }
}
