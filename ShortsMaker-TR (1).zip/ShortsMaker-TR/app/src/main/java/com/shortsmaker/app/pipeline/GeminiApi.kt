package com.shortsmaker.app.pipeline

import com.shortsmaker.app.data.AppLog
import com.shortsmaker.app.story.await
import kotlinx.coroutines.delay
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** استدعاء Gemini generateContent بإخراج JSON، مع إعادة المحاولة عند انقطاع الشبكة أو الازدحام. */
object GeminiApi {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).callTimeout(300, TimeUnit.SECONDS).readTimeout(300, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS).build()

    fun textPart(t: String): JSONObject = JSONObject().put("text", t)

    suspend fun json(apiKey: String, model: String, parts: List<JSONObject>): JSONObject {
        val clean = request(apiKey, model, parts, asJson = true)
        val start = clean.indexOf('{')
        val end = clean.lastIndexOf('}')
        if (start < 0 || end <= start) error("Gemini yanıtı geçerli JSON değil")
        return try { JSONObject(clean.substring(start, end + 1)) } catch (e: org.json.JSONException) {
            error("Gemini yanıtı eksik (yanıt kesildi)")
        }
    }

    /** نص خام (بدون JSON): أخفّ وأقل عرضة للانقطاع، ويُستعمل لتفريغ الصوت. */
    suspend fun text(apiKey: String, model: String, parts: List<JSONObject>): String =
        request(apiKey, model, parts, asJson = false)

    private suspend fun request(apiKey: String, model: String, parts: List<JSONObject>, asJson: Boolean): String {
        val cfg = JSONObject().put("temperature", if (asJson) 0.6 else 0.2).put("maxOutputTokens", 16384)
        if (asJson) cfg.put("responseMimeType", "application/json")
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray(parts))))
            .put("generationConfig", cfg)
            .toString()
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toRequestBody("application/json".toMediaType())).build()

        var raw = ""
        var lastErr: Exception? = null
        for (attempt in 1..4) {
            try {
                raw = http.newCall(req).await().use { r ->
                    val s = r.body?.string().orEmpty()
                    if (r.code == 429 || r.code >= 500) throw java.io.IOException("Gemini HTTP ${r.code}")
                    if (!r.isSuccessful) error("Gemini HTTP ${r.code}: ${s.take(300)}")
                    s
                }
                lastErr = null
                break
            } catch (e: java.io.IOException) {
                lastErr = e
                AppLog.add("   ⚠ Gemini'den yanıt gelmedi (deneme $attempt/4): ${e.message}")
                if (attempt < 4) delay(8_000L * attempt)
            }
        }
        lastErr?.let { error("4 denemeden sonra Gemini'ye ulaşılamadı (${it.message})") }

        val text = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        return text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
    }
}
