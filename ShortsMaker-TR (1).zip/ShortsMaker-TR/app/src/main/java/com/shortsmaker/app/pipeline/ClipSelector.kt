package com.shortsmaker.app.pipeline

import org.json.JSONArray
import java.util.Locale
import kotlin.math.abs

class ClipPick(val start: Double, val end: Double, val title: String, val hook: String, val tags: String)

/** Gemini يختار أفضل اللحظات من النص، ثم نبني الكتابة (الكابشن) العربية لكل مقطع. */
object ClipSelector {

    suspend fun pick(
        apiKey: String, model: String, t: Transcript, videoTitle: String,
        count: Int, minSec: Int, maxSec: Int,
    ): List<ClipPick> {
        val transcript = buildString {
            for (s in t.segs) append("[").append(String.format(Locale.US, "%.1f", s.start)).append("] ").append(s.text).append('\n')
        }
        val prompt = """
You are a viral short-form video editor (TikTok / Reels / YouTube Shorts).
Below is the timestamped transcript of a video titled "$videoTitle". Each line is "[start_seconds] text".

Pick up to $count of the BEST self-contained moments to cut as vertical Shorts.
Rules:
- Each clip is between $minSec and $maxSec seconds long.
- A clip starts at the beginning of a line and ends where a sentence ends (never mid-sentence).
- The first 3 seconds must hook the viewer (a question, a surprise, a strong claim, or the start of a gripping story beat).
- Prefer complete mini-stories, strong emotional or surprising moments, and clear valuable ideas. A clip must make sense without the rest of the video.
- Clips must not overlap each other.
- Use only times that exist in the transcript.

Return ONLY JSON:
{"clips":[{"start":12.5,"end":58.0,"title":"catchy Turkish title, max 60 chars","hook":"one short Turkish hook sentence for the post description","hashtags":["#...","#...","#...","#...","#..."]}]}
Hashtag rules: exactly 5 hashtags per clip, no spaces inside a tag, in the same language as the video (Turkish video -> Turkish tags). Mix: 2 specific to the clip's topic, 2 about the wider niche/category, 1 broad discovery tag (e.g. #shorts or #reels). Real tags people search for; no spam, no repeats.

TRANSCRIPT:
$transcript
""".trimIndent()

        val j = GeminiApi.json(apiKey, model, listOf(GeminiApi.textPart(prompt)))
        val arr = j.optJSONArray("clips") ?: JSONArray()
        val out = mutableListOf<ClipPick>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            var s = o.optDouble("start", Double.NaN)
            var e = o.optDouble("end", Double.NaN)
            if (s.isNaN() || e.isNaN() || e <= s) continue
            // نلصق البداية والنهاية بحدود أقرب سطر في النص
            t.segs.minByOrNull { abs(it.start - s) }?.let { if (abs(it.start - s) <= 3.0) s = it.start }
            t.segs.minByOrNull { abs(it.end - e) }?.let { if (abs(it.end - e) <= 3.0) e = it.end }
            if (e - s > maxSec + 8) e = s + maxSec
            if (e > t.duration + 1.0) e = t.duration
            if (e - s < 8.0) continue
            if (out.any { s < it.end && e > it.start }) continue
            val tags = o.optJSONArray("hashtags")?.let { a -> (0 until a.length()).joinToString(" ") { a.optString(it) } } ?: ""
            out += ClipPick(s, e, o.optString("title", videoTitle).take(90), o.optString("hook"), tags)
            if (out.size >= count) break
        }
        return out
    }

    /** يبني سطور الكتابة لنافذة [start, end] بأزمنة نسبية لبداية المقطع، ثم يترجمها للعربية عند الحاجة. */
    suspend fun cues(apiKey: String, model: String, t: Transcript, start: Double, end: Double): List<Cue> {
        val cues = mutableListOf<Cue>()
        for (s in t.segs) {
            if (s.end <= start || s.start >= end) continue
            val a = maxOf(s.start, start) - start
            val b = minOf(s.end, end) - start
            if (b - a < 0.2) continue
            val words = s.text.split(" ").filter { it.isNotEmpty() }
            val chunks = words.chunked(7).map { it.joinToString(" ") }
            val totalChars = chunks.sumOf { it.length }.toDouble().coerceAtLeast(1.0)
            var cur = a
            for (c in chunks) {
                val d = (b - a) * c.length / totalChars
                cues += Cue(cur, cur + d, c)
                cur += d
            }
        }
        if (cues.isEmpty() || t.isTurkish) return cues

        val numbered = cues.mapIndexed { i, c -> "${i + 1}. ${c.text}" }.joinToString("\n")
        val prompt = """
Translate each numbered subtitle line below into natural, simple, spoken everyday Turkish (not stiff or formal).
Keep EXACTLY the same number of lines and the same order. Keep each line short.
Return ONLY JSON: {"lines":["...","..."]}

$numbered
""".trimIndent()
        var lastErr: Exception? = null
        for (attempt in 1..2) {
            try {
                val j = GeminiApi.json(apiKey, model, listOf(GeminiApi.textPart(prompt)))
                val a = j.getJSONArray("lines")
                if (a.length() == cues.size)
                    return cues.mapIndexed { i, c -> Cue(c.start, c.end, a.getString(i).trim().ifEmpty { c.text }) }
                lastErr = IllegalStateException("Çevrilen satır sayısı orijinalle uyuşmuyor")
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                lastErr = e
            }
        }
        com.shortsmaker.app.data.AppLog.add("   ⚠ Türkçeye çeviri başarısız (${lastErr?.message?.take(80)}), altyazı özgün dilinde kalacak")
        return cues
    }
}

/** دمج وسوم الذكاء الاصطناعي مع وسوم المستخدم: بلا تكرار وبحدّ أقصى مناسب. */
object Hashtags {
    fun merge(ai: String, user: String, max: Int = 10): String {
        val out = LinkedHashMap<String, String>()
        for (raw in "$ai $user".split(Regex("\\s+"))) {
            var t = raw.trim().trim(',', '،')
            if (t.isEmpty()) continue
            if (!t.startsWith("#")) t = "#$t"
            if (t.length < 2) continue
            out.putIfAbsent(t.lowercase(), t)
        }
        return out.values.take(max).joinToString(" ")
    }
}
