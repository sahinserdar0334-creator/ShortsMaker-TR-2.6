package com.shortsmaker.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.UUID

/** عنصر في طابور النشر: مقطع جاهز + حالته على كل منصة. */
data class QueueItem(
    val id: String,
    val file: String,
    val title: String,
    val description: String,
    val scheduledAt: Long,
    val status: MutableMap<String, String>,   // platform -> pending | done | failed
    val attempts: MutableMap<String, Int>,
)

/** طابور دائم (ملف JSON) يبقى بعد إغلاق التطبيق أو إعادة تشغيل الهاتف. */
object UploadQueue {
    private val lock = Any()
    private fun file(ctx: Context) = File(ctx.filesDir, "upload_queue.json")
    private fun dir(ctx: Context) = File(ctx.filesDir, "queue").apply { mkdirs() }

    fun load(ctx: Context): MutableList<QueueItem> = synchronized(lock) {
        val f = file(ctx)
        if (!f.exists()) return mutableListOf()
        val arr = try { JSONArray(f.readText()) } catch (e: Exception) { return mutableListOf() }
        val out = mutableListOf<QueueItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val st = mutableMapOf<String, String>()
            val at = mutableMapOf<String, Int>()
            o.getJSONObject("status").let { s -> s.keys().forEach { st[it] = s.getString(it) } }
            o.optJSONObject("attempts")?.let { s -> s.keys().forEach { at[it] = s.getInt(it) } }
            out += QueueItem(
                o.getString("id"), o.getString("file"), o.getString("title"),
                o.getString("description"), o.getLong("scheduledAt"), st, at,
            )
        }
        out
    }

    fun save(ctx: Context, items: List<QueueItem>) = synchronized(lock) {
        val arr = JSONArray()
        for (it in items) arr.put(
            JSONObject().put("id", it.id).put("file", it.file).put("title", it.title)
                .put("description", it.description).put("scheduledAt", it.scheduledAt)
                .put("status", JSONObject(it.status as Map<*, *>))
                .put("attempts", JSONObject(it.attempts as Map<*, *>))
        )
        file(ctx).writeText(arr.toString())
    }

    /** ينسخ المقطع إلى مجلد التطبيق الخاص ويضيفه للطابور. */
    fun add(
        ctx: Context, src: File, title: String, description: String,
        platforms: List<String>, scheduledAt: Long,
    ): QueueItem = synchronized(lock) {
        val id = UUID.randomUUID().toString().take(8)
        val dest = File(dir(ctx), "$id.mp4")
        src.copyTo(dest, overwrite = true)
        val item = QueueItem(
            id, dest.absolutePath, title, description, scheduledAt,
            platforms.associateWith { "pending" }.toMutableMap(), mutableMapOf(),
        )
        val list = load(ctx); list += item; save(ctx, list)
        item
    }

    fun pendingCount(ctx: Context) = load(ctx).count { it.status.values.any { s -> s == "pending" } }

    fun lastScheduled(ctx: Context): Long = load(ctx).maxOfOrNull { it.scheduledAt } ?: 0L

    /** يحذف العناصر المنتهية (كل المنصات done/failed) وملفاتها. */
    fun cleanup(ctx: Context) = synchronized(lock) {
        val list = load(ctx)
        val (finished, keep) = list.partition { it.status.values.none { s -> s == "pending" } }
        finished.forEach { File(it.file).delete() }
        save(ctx, keep)
    }

    /** أول موعد نشر من الأوقات اليومية (HH:mm) بعد اللحظة المعطاة. */
    fun nextSlot(times: String, afterMs: Long): Long {
        val slots = times.split(",").mapNotNull { t ->
            val p = t.trim().split(":")
            val h = p.getOrNull(0)?.toIntOrNull(); val m = p.getOrNull(1)?.toIntOrNull()
            if (h != null && m != null && h in 0..23 && m in 0..59) h to m else null
        }.sortedWith(compareBy({ it.first }, { it.second }))
        if (slots.isEmpty()) return afterMs
        for (day in 0..60) {
            for ((h, m) in slots) {
                val c = Calendar.getInstance().apply {
                    timeInMillis = afterMs
                    add(Calendar.DAY_OF_YEAR, day)
                    set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                if (c.timeInMillis > afterMs) return c.timeInMillis
            }
        }
        return afterMs
    }
}
