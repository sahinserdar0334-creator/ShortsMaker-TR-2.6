package com.shortsmaker.app.data

import android.content.Context

/** قناة مع المنصات التي تُنشر عليها مقاطعها. [platforms] فارغة = كل المنصات المفعّلة. */
class ChannelSpec(val handle: String, val platforms: Set<String>) {
    fun serialize(): String =
        if (platforms.isEmpty()) handle else "$handle | ${platforms.sorted().joinToString(",")}"

    companion object {
        val ALL = listOf("yt", "tt", "ig")
        fun parse(line: String): ChannelSpec? {
            val t = line.trim()
            if (t.isEmpty()) return null
            val i = t.lastIndexOf('|')
            if (i < 0) return ChannelSpec(t, emptySet())
            val handle = t.substring(0, i).trim()
            if (handle.isEmpty()) return null
            val toks = t.substring(i + 1).lowercase().split(',', ' ').map { it.trim() }.filter { it.isNotEmpty() }
            val set = if (toks.contains("all")) emptySet() else toks.filter { it in ALL }.toSet()
            return ChannelSpec(handle, set)
        }
    }
}

class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val creds = Creds(ctx)

    var geminiKey: String
        get() = creds.geminiKey
        set(v) { creds.geminiKey = v }

    var model: String
        get() = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) = sp.edit().putString("model", v.trim()).apply()

    // ---------- النشر التلقائي ----------
    /** off | now | schedule */
    var publishMode: String
        get() = sp.getString("publish_mode", "off") ?: "off"
        set(v) = sp.edit().putString("publish_mode", v).apply()

    /** أوقات النشر اليومية بصيغة HH:mm مفصولة بفواصل، مثل 12:00,18:00,21:00 */
    var scheduleTimes: String
        get() = sp.getString("schedule_times", "12:00,18:00,21:00") ?: "12:00,18:00,21:00"
        set(v) = sp.edit().putString("schedule_times", v).apply()

    /** كتابة (ترجمة) مدمجة على الفيديو: تشغيل/إيقاف. الافتراضي: إيقاف. */
    var captions: Boolean
        get() = sp.getBoolean("captions", false)
        set(v) = sp.edit().putBoolean("captions", v).apply()

    var hashtags: String
        get() = sp.getString("hashtags", "#shorts #kesit") ?: "#shorts #kesit"
        set(v) = sp.edit().putString("hashtags", v).apply()

    /** سطر ثابت (دعوة للاشتراك/المتابعة) يُضاف بعد جملة الوصف الأولى على يوتيوب وإنستا فقط. */
    var fixedLine: String
        get() = sp.getString("fixed_line", "🔔 Her gün yeni içerik için bizi takip et") ?: ""
        set(v) = sp.edit().putString("fixed_line", v).apply()

    /** يُدخل [fixedLine] بعد الفقرة الأولى من الوصف (تظهر قبل «عرض المزيد»). */
    fun withCta(desc: String): String {
        val cta = fixedLine.trim()
        if (cta.isEmpty()) return desc
        val i = desc.indexOf("\n\n")
        return if (i < 0) "$desc\n\n$cta" else desc.substring(0, i) + "\n\n" + cta + desc.substring(i)
    }

    var pubYouTube: Boolean
        get() = sp.getBoolean("pub_yt", false)
        set(v) = sp.edit().putBoolean("pub_yt", v).apply()

    var pubTikTok: Boolean
        get() = sp.getBoolean("pub_tt", false)
        set(v) = sp.edit().putBoolean("pub_tt", v).apply()

    var pubInstagram: Boolean
        get() = sp.getBoolean("pub_ig", false)
        set(v) = sp.edit().putBoolean("pub_ig", v).apply()

    /** private | unlisted | public */
    var ytPrivacy: String
        get() = sp.getString("yt_privacy", "private") ?: "private"
        set(v) = sp.edit().putString("yt_privacy", v).apply()

    /** draft = يصل إلى مسودات تيك توك لتنشره بنفسك، direct = نشر مباشر (يحتاج اعتماد التطبيق من تيك توك) */
    var ttMode: String
        get() = sp.getString("tt_mode", "draft") ?: "draft"
        set(v) = sp.edit().putString("tt_mode", v).apply()

    var ttPrivacy: String
        get() = sp.getString("tt_privacy", "SELF_ONLY") ?: "SELF_ONLY"
        set(v) = sp.edit().putString("tt_privacy", v).apply()

    // ---------- القنوات والتقطيع ----------
    /** قناة في كل سطر: @handle أو رابط القناة أو معرّف UC... */
    var channels: String
        get() = sp.getString("channels", "") ?: ""
        set(v) = sp.edit().putString("channels", v).apply()

    var videosPerChannel: Int
        get() = sp.getInt("videos_per_channel", 1)
        set(v) = sp.edit().putInt("videos_per_channel", v.coerceIn(1, 5)).apply()

    var clipsPerVideo: Int
        get() = sp.getInt("clips_per_video", 3)
        set(v) = sp.edit().putInt("clips_per_video", v.coerceIn(1, 8)).apply()

    var clipMinSec: Int
        get() = sp.getInt("clip_min_sec", 25)
        set(v) = sp.edit().putInt("clip_min_sec", v.coerceIn(10, 90)).apply()

    var clipMaxSec: Int
        get() = sp.getInt("clip_max_sec", 55)
        set(v) = sp.edit().putInt("clip_max_sec", v.coerceIn(15, 180)).apply()

    /** كل سطر: "@kanal | yt,tt,ig" (all أو بدون لاحقة = كل المنصات المفعّلة). */
    fun channelSpecs(): List<ChannelSpec> = channels.lines().mapNotNull { ChannelSpec.parse(it) }

    fun channelList(): List<String> = channelSpecs().map { it.handle }

    private fun doneSet(): MutableList<String> =
        (sp.getString("done_ids", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    fun isDone(id: String) = doneSet().contains(id)
    fun markDone(id: String) {
        val l = doneSet().apply { remove(id); add(id) }
        sp.edit().putString("done_ids", l.takeLast(600).joinToString(",")).apply()
    }
    fun clearDone() = sp.edit().remove("done_ids").apply()

    // ---------- وضع القصص ----------
    var storyPremise: String
        get() = sp.getString("story_premise", "") ?: ""
        set(v) = sp.edit().putString("story_premise", v).apply()

    var storyStyle: String
        get() = sp.getString("story_style", "Günlük sade Türkçe, gizem ve gerilim") ?: ""
        set(v) = sp.edit().putString("story_style", v).apply()

    var storyParts: Int
        get() = sp.getInt("story_parts", 4)
        set(v) = sp.edit().putInt("story_parts", v.coerceIn(2, 10)).apply()

    var ttsModel: String
        get() = sp.getString("tts_model", "gemini-3.8-flash-tts") ?: "gemini-3.8-flash-tts"
        set(v) = sp.edit().putString("tts_model", v.trim()).apply()

    var ttsVoice: String
        get() = sp.getString("tts_voice", "Charon") ?: "Charon"
        set(v) = sp.edit().putString("tts_voice", v.trim()).apply()

    var ttsStyle: String
        get() = sp.getString("tts_style", "Gerilimli hikâyeler anlatan profesyonel bir anlatıcı gibi, Türkçe, sakin ve gizemli bir tonla, orta tempoda oku") ?: ""
        set(v) = sp.edit().putString("tts_style", v).apply()

    fun enabledPlatforms(): List<String> = buildList {
        if (pubYouTube) add("youtube")
        if (pubTikTok) add("tiktok")
        if (pubInstagram) add("instagram")
    }
}
