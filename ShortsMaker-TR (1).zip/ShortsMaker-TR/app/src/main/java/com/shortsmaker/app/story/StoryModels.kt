package com.shortsmaker.app.story

data class Scene(val text: String, val mood: String, val visualPrompt: String, val characters: List<String>)
data class Part(val n: Int, val title: String, val scenes: List<Scene>, val teaser: String) {
    val fullText get() = scenes.joinToString(" ") { it.text }
}
data class Character(val name: String, val role: String, val visual: String)
data class Story(
    val title: String,
    val logline: String,
    val artStyle: String,
    val characters: List<Character>,
    val parts: List<Part>,
    val hashtags: String,
)
