package com.shortsmaker.app.publish

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.shortsmaker.app.App
import com.shortsmaker.app.data.AppLog
import com.shortsmaker.app.data.Creds
import com.shortsmaker.app.data.Report
import com.shortsmaker.app.data.Settings
import com.shortsmaker.app.data.UploadQueue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/** ينفّذ النشر لكل عنصر حان موعده في الطابور. */
object PublishRunner {
    private val mutex = Mutex() // يمنع تشغيلين متزامنين من نشر العنصر نفسه مرتين
    private const val MAX_ATTEMPTS = 3

    suspend fun runDue(ctx: Context): Int = mutex.withLock {
        val settings = Settings(ctx)
        val creds = Creds(ctx)
        var done = 0
        val now = System.currentTimeMillis()
        val items = UploadQueue.load(ctx)
        val due = items.filter { it.scheduledAt <= now && it.status.values.any { s -> s == "pending" } }

        for (item in due) {
            val file = File(item.file)
            for (platform in item.status.keys.toList()) {
                if (item.status[platform] != "pending") continue
                if (!file.exists()) { item.status[platform] = "failed"; Report.add(ctx, "pub_fail", platform, item.title, "Dosya bulunamadı"); continue }
                try {
                    AppLog.add("⬆ [$platform] ${item.title}")
                    val msg = withContext(Dispatchers.IO) {
                        when (platform) {
                            "youtube" -> YouTubeUploader.upload(creds, settings, file, item.title, settings.withCta(item.description))
                            "tiktok" -> TikTokUploader.upload(creds, settings, file, item.description)
                            "instagram" -> InstagramUploader.upload(creds, file, settings.withCta(item.description))
                            else -> error("Bilinmeyen platform")
                        }
                    }
                    item.status[platform] = "done"
                    AppLog.add("   ✔ $msg")
                    Report.add(ctx, "pub_ok", platform, item.title, msg.toString())
                    done++
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    val n = (item.attempts[platform] ?: 0) + 1
                    item.attempts[platform] = n
                    if (n >= MAX_ATTEMPTS) item.status[platform] = "failed"
                    AppLog.add("   ✗ [$platform] deneme $n/$MAX_ATTEMPTS: ${e.message}")
                    Report.add(ctx, "pub_fail", platform, item.title, "deneme $n/$MAX_ATTEMPTS: ${e.message?.take(140)}")
                }
                UploadQueue.save(ctx, items) // احفظ التقدم بعد كل منصة
            }
        }
        UploadQueue.save(ctx, items)
        UploadQueue.cleanup(ctx)
        done
    }
}

class PublishWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val now = System.currentTimeMillis()
        val hasDue = UploadQueue.load(ctx).any { it.scheduledAt <= now && it.status.values.any { s -> s == "pending" } }
        if (!hasDue) return Result.success()

        runCatching { setForeground(foreground()) } // قد يُمنع في الخلفية على أندرويد 12+، نكمل بدونه
        return try {
            PublishRunner.runDue(ctx)
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            AppLog.add("✗ Yayın hatası: ${e.message}")
            Result.retry()
        }
    }

    private fun foreground(): ForegroundInfo {
        val n = NotificationCompat.Builder(ctx, App.CHANNEL_ID)
            .setContentTitle("Shorts Maker").setContentText("Klipler yayınlanıyor...")
            .setSmallIcon(android.R.drawable.stat_sys_upload).setOngoing(true).build()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ForegroundInfo(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(2, n)
    }
}

object PublishScheduler {
    private val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    /** نشر فوري لما حان موعده. */
    fun kickNow(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<PublishWorker>().setConstraints(net).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("publish_now", ExistingWorkPolicy.APPEND_OR_REPLACE, req)
    }

    /** فحص دوري كل 15 دقيقة (أقل مدة يسمح بها أندرويد) لنشر ما حان موعده. */
    fun ensurePeriodic(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<PublishWorker>(15, TimeUnit.MINUTES).setConstraints(net).build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork("publish_tick", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun cancelPeriodic(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork("publish_tick")
    }
}
