package com.shortsmaker.app.pipeline

/** سطر كتابة على الفيديو بالثواني (يُستخدم للكتابة المتزامنة مع الصوت). */
data class Cue(val start: Double, val end: Double, val text: String)
