package com.shortsmaker.app.publish

import com.shortsmaker.app.data.Creds
import com.shortsmaker.app.data.Settings
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File

object YouTubeUploader {
    /** رفع resumable إلى YouTube Data API v3 (videos.insert). */
    fun upload(c: Creds, s: Settings, file: File, title: String, description: String): String {
        val token = YouTubeAuth.accessToken(c)
        val mp4 = "video/mp4".toMediaType()
        val body = JSONObject()
            .put(
                "snippet", JSONObject()
                    .put("title", title.take(95))
                    .put("description", description.take(4800))
                    .put("categoryId", "22")
            )
            .put(
                "status", JSONObject()
                    .put("privacyStatus", s.ytPrivacy)
                    .put("selfDeclaredMadeForKids", false)
            ).toString()

        val init = Request.Builder()
            .url("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status")
            .header("Authorization", "Bearer $token")
            .header("X-Upload-Content-Length", file.length().toString())
            .header("X-Upload-Content-Type", "video/mp4")
            .post(body.toRequestBody("application/json; charset=UTF-8".toMediaType()))
            .build()
        val location = Net.client.newCall(init).execute().use { r ->
            if (!r.isSuccessful) error("YouTube init HTTP ${r.code}: ${r.body?.string()?.take(400)}")
            r.header("Location") ?: error("YouTube yükleme bağlantısı yok")
        }
        val put = Request.Builder().url(location).header("Authorization", "Bearer $token")
            .put(file.asRequestBody(mp4)).build()
        val j = Net.json(put)
        return "https://youtube.com/shorts/${j.getString("id")} (${s.ytPrivacy})"
    }
}

object TikTokUploader {
    private const val MB = 1024L * 1024L

    fun upload(c: Creds, s: Settings, file: File, caption: String): String {
        val token = TikTokAuth.accessToken(c)
        val size = file.length()
        val chunk = if (size <= 64 * MB) size else 32 * MB
        val total = if (size <= 64 * MB) 1L else size / chunk // آخر دفعة تستوعب الباقي

        val direct = s.ttMode == "direct"
        val body = JSONObject().put(
            "source_info", JSONObject().put("source", "FILE_UPLOAD").put("video_size", size)
                .put("chunk_size", chunk).put("total_chunk_count", total)
        )
        if (direct) body.put(
            "post_info", JSONObject().put("title", caption.take(2000))
                .put("privacy_level", s.ttPrivacy)
                .put("disable_duet", false).put("disable_comment", false).put("disable_stitch", false)
        )
        val path = if (direct) "/v2/post/publish/video/init/" else "/v2/post/publish/inbox/video/init/"
        val init = Net.json(
            Request.Builder().url("https://open.tiktokapis.com$path")
                .header("Authorization", "Bearer $token")
                .post(body.toString().toRequestBody("application/json; charset=UTF-8".toMediaType())).build()
        )
        val err = init.optJSONObject("error")
        if (err != null && err.optString("code") != "ok") error("TikTok: ${err.optString("code")} ${err.optString("message")}")
        val data = init.getJSONObject("data")
        val uploadUrl = data.getString("upload_url")

        val type = "video/mp4".toMediaType()
        var offset = 0L
        for (i in 0 until total) {
            val len = if (i == total - 1) size - offset else chunk
            val req = Request.Builder().url(uploadUrl)
                .header("Content-Range", "bytes $offset-${offset + len - 1}/$size")
                .put(FileSliceBody(file, offset, len, type)).build()
            Net.client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("TikTok upload HTTP ${r.code}: ${r.body?.string()?.take(300)}")
            }
            offset += len
        }
        return if (direct) "TikTok'ta yayınlandı (${s.ttPrivacy})" else "TikTok taslaklarına ulaştı — uygulamayı açıp yayınla"
    }
}

object InstagramUploader {
    private const val V = "v23.0" // رقم إصدار Graph API؛ حدّثه إن انتهت صلاحيته

    fun upload(c: Creds, file: File, caption: String): String {
        require(c.igUserId.isNotBlank() && c.igToken.isNotBlank()) { "Instagram bilgileri eksik" }
        val auth = "OAuth ${c.igToken}"

        val created = Net.json(
            Request.Builder().url("https://graph.facebook.com/$V/${c.igUserId}/media").post(
                FormBody.Builder().add("media_type", "REELS").add("upload_type", "resumable")
                    .add("caption", caption.take(2200)).add("access_token", c.igToken).build()
            ).build()
        )
        val id = created.getString("id")
        val uploadUrl = created.optString("uri").ifBlank { "https://rupload.facebook.com/ig-api-upload/$V/$id" }

        Net.json(
            Request.Builder().url(uploadUrl).header("Authorization", auth)
                .header("offset", "0").header("file_size", file.length().toString())
                .post(file.asRequestBody("application/octet-stream".toMediaType())).build()
        )

        // انتظار انتهاء المعالجة (حتى 6 دقائق)
        var ok = false
        var tries = 0
        while (!ok && tries++ < 72) {
            val st = Net.json(
                Request.Builder().url("https://graph.facebook.com/$V/$id?fields=status_code,status")
                    .header("Authorization", auth).build()
            )
            when (st.optString("status_code")) {
                "FINISHED" -> ok = true
                "ERROR", "EXPIRED" -> error("Instagram işleme başarısız: ${st.optString("status")}")
            }
            if (!ok) Thread.sleep(5000)
        }
        if (!ok) error("Instagram işleme süresi doldu")

        val pub = Net.json(
            Request.Builder().url("https://graph.facebook.com/$V/${c.igUserId}/media_publish").post(
                FormBody.Builder().add("creation_id", id).add("access_token", c.igToken).build()
            ).build()
        )
        return "Instagram'da Reel yayınlandı (id ${pub.optString("id")})"
    }
}
