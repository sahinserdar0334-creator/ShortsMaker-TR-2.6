package com.shortsmaker.app.pipeline

import android.content.Context
import com.shortsmaker.app.data.AppLog
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File

class Video(val id: String, val title: String, val channel: String)

/** غلاف حول yt-dlp: تهيئة، تحديث، سرد أحدث الفيديوهات، تنزيل الترجمة، وتنزيل مقطع محدد فقط. */
object Yt {
    @Volatile private var inited = false

    // عملاء يوتيوب البديلة: إذا حُظر أحدها (403 / SABR) نجرّب الذي بعده
    private val clients = listOf<String?>(null, "tv", "android_vr", "web_safari", "mweb")

    suspend fun init(ctx: Context) = withContext(Dispatchers.IO) {
        if (inited) return@withContext
        YoutubeDL.getInstance().init(ctx)
        FFmpeg.getInstance().init(ctx)
        inited = true
    }

    /** يحدّث yt-dlp إلى آخر إصدار (يوتيوب يغيّر آلياته باستمرار). الفشل هنا غير قاتل. */
    suspend fun update(ctx: Context): String = withContext(Dispatchers.IO) {
        try { "${YoutubeDL.getInstance().updateYoutubeDL(ctx)}" } catch (e: Exception) { "Güncellenemedi: ${e.message}" }
    }

    private suspend fun exec(url: String, opts: List<Pair<String, String?>>): String = coroutineScope {
        val id = "yt${System.nanoTime()}"
        val req = YoutubeDLRequest(url)
        for ((k, v) in opts) if (v == null) req.addOption(k) else req.addOption(k, v)
        val job = async(Dispatchers.IO) { YoutubeDL.getInstance().execute(req, id) { _, _, _ -> }.out }
        try {
            job.await()
        } catch (e: CancellationException) {
            runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
            throw e
        }
    }

    private fun shortErr(e: Exception): String {
        val m = e.message.orEmpty()
        val line = m.lines().lastOrNull { it.contains("ERROR", true) } ?: m.lines().lastOrNull { it.isNotBlank() } ?: m
        return line.take(220)
    }

    fun channelUrl(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http") -> {
                val u = t.trimEnd('/')
                if (u.contains("/videos") || u.contains("watch?") || u.contains("playlist")) u else "$u/videos"
            }
            t.startsWith("@") -> "https://www.youtube.com/$t/videos"
            t.startsWith("UC") && t.length >= 20 -> "https://www.youtube.com/channel/$t/videos"
            else -> "https://www.youtube.com/@$t/videos"
        }
    }

    /** أحدث [count] فيديوهات للقناة (بدون Shorts) عبر قائمة مبسّطة سريعة. */
    suspend fun latest(channel: String, count: Int): List<Video> {
        var last: Exception? = null
        for (c in clients.take(3)) {
            try {
                val opts = mutableListOf<Pair<String, String?>>(
                    "--flat-playlist" to null, "--playlist-end" to count.toString(),
                    "--print" to "%(id)s ||| %(title)s", "--no-warnings" to null, "--socket-timeout" to "30",
                )
                if (c != null) opts += "--extractor-args" to "youtube:player_client=$c"
                val out = exec(channelUrl(channel), opts)
                val list = out.lines().mapNotNull { l ->
                    val p = l.split(" ||| ", limit = 2)
                    if (p.size == 2 && p[0].trim().length in 8..16) Video(p[0].trim(), p[1].trim(), channel) else null
                }
                if (list.isNotEmpty()) return list
            } catch (e: CancellationException) { throw e } catch (e: Exception) { last = e }
        }
        error("Kanal okunamadı «$channel»: ${last?.let { shortErr(it) } ?: "sonuç yok"}")
    }

    /**
     * ينزّل ملفات الترجمة للفيديو فقط. لا نطلب ترجمة آلية إلى لغة أخرى (هي سبب خطأ 429):
     * المرحلة 1: الترجمة التلقائية بلغة الفيديو الأصلية أياً كانت (xx-orig: عربي/تركي/إنجليزي...)،
     * المرحلة 2: الترجمة اليدوية فقط إن وُجدت. وعند 429 ننتظر ونعيد المحاولة.
     */
    suspend fun subtitles(id: String, dir: File): List<File> {
        dir.mkdirs()
        var last: Exception? = null
        val passes = listOf(
            listOf("--write-auto-subs" to null, "--sub-langs" to ".*-orig"),
            listOf("--write-subs" to null, "--sub-langs" to "ar,en,tr"),
        )
        for (pass in passes) {
            for (c in clients.take(3)) {
                var retry = 0
                while (true) {
                    try {
                        val opts = mutableListOf<Pair<String, String?>>(
                            "--skip-download" to null, "--sub-format" to "json3",
                            "-o" to "${dir.absolutePath}/$id.%(ext)s", "--no-playlist" to null,
                            "--no-warnings" to null, "--socket-timeout" to "30",
                        )
                        opts += pass
                        if (c != null) opts += "--extractor-args" to "youtube:player_client=$c"
                        exec("https://www.youtube.com/watch?v=$id", opts)
                        val files = dir.listFiles { f -> f.name.endsWith(".json3") }?.toList().orEmpty()
                        if (files.isNotEmpty()) return files
                        break // لا ترجمة بهذا الطلب: جرّب المرحلة التالية
                    } catch (e: CancellationException) { throw e } catch (e: Exception) {
                        last = e
                        val files = dir.listFiles { f -> f.name.endsWith(".json3") }?.toList().orEmpty()
                        if (files.isNotEmpty()) return files // نزل بعضها قبل الخطأ
                        if (e.message.orEmpty().contains("429") && retry < 2) {
                            retry++
                            AppLog.add("   ⏳ YouTube beklemeni istiyor, yeniden deniyorum ($retry/2)...")
                            kotlinx.coroutines.delay(6_000L * retry)
                            continue
                        }
                        break
                    }
                }
            }
        }
        if (last != null) AppLog.add("   ⚠ Altyazı alınamadı: ${shortErr(last)}")
        return emptyList()
    }

    /** مدة الفيديو بالثواني (0 إن تعذر). */
    suspend fun duration(id: String): Double {
        for (c in clients.take(3)) {
            try {
                val opts = mutableListOf<Pair<String, String?>>(
                    "--print" to "%(duration)s", "--no-playlist" to null, "--no-warnings" to null, "--socket-timeout" to "30",
                )
                if (c != null) opts += "--extractor-args" to "youtube:player_client=$c"
                exec("https://www.youtube.com/watch?v=$id", opts).lines()
                    .firstNotNullOfOrNull { it.trim().toDoubleOrNull() }?.let { return it }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { /* التالي */ }
        }
        return 0.0
    }

    /** جزء صوتي صغير [startSec, endSec] من الفيديو (للتفريغ على دفعات). */
    suspend fun audioSection(id: String, startSec: Double, endSec: Double, dir: File): File? {
        dir.mkdirs()
        for (c in clients.take(3)) {
            try {
                dir.listFiles()?.forEach { it.delete() }
                val opts = mutableListOf<Pair<String, String?>>(
                    "-f" to "worstaudio[ext=m4a]/worstaudio",
                    "--download-sections" to "*%.1f-%.1f".format(java.util.Locale.US, startSec, endSec),
                    "-o" to "${dir.absolutePath}/part.%(ext)s",
                    "--no-playlist" to null, "--no-warnings" to null, "--socket-timeout" to "30", "--retries" to "3",
                )
                if (c != null) opts += "--extractor-args" to "youtube:player_client=$c"
                exec("https://www.youtube.com/watch?v=$id", opts)
                dir.listFiles { f -> f.isFile && f.length() > 2_000 && !f.name.endsWith(".part") }?.firstOrNull()?.let { return it }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { /* التالي */ }
        }
        return null
    }

    /** أصغر نسخة صوتية (لتفريغها بالذكاء الاصطناعي عندما لا توجد ترجمة). */
    suspend fun audio(id: String, dir: File): File? {
        dir.mkdirs()
        for (c in clients.take(3)) {
            try {
                val opts = mutableListOf<Pair<String, String?>>(
                    "-f" to "worstaudio[ext=m4a]/worstaudio", "-o" to "${dir.absolutePath}/$id.%(ext)s",
                    "--no-playlist" to null, "--no-warnings" to null, "--socket-timeout" to "30",
                )
                if (c != null) opts += "--extractor-args" to "youtube:player_client=$c"
                exec("https://www.youtube.com/watch?v=$id", opts)
                dir.listFiles { f -> f.isFile && !f.name.endsWith(".part") }?.firstOrNull()?.let { return it }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { /* التالي */ }
        }
        return null
    }

    private const val FMT = "bv*[height<=1080][vcodec^=avc1]+ba[ext=m4a]/bv*[height<=1080]+ba/b[height<=1080]/b"

    /**
     * ينزّل المقطع المطلوب فقط [startSec, endSec] بدقة إطارية.
     * يعيد الملف و«هل هو مقطع جاهز أم فيديو كامل» (عند الفشل نرجع لتنزيل الفيديو كاملاً).
     */
    suspend fun clip(id: String, startSec: Double, endSec: Double, dir: File): Pair<File, Boolean> {
        dir.mkdirs()
        var last: Exception? = null
        for (c in clients) {
            try {
                dir.listFiles()?.forEach { it.delete() }
                val opts = mutableListOf<Pair<String, String?>>(
                    "-f" to FMT, "--merge-output-format" to "mp4",
                    "--download-sections" to "*%.2f-%.2f".format(java.util.Locale.US, startSec, endSec),
                    "--force-keyframes-at-cuts" to null,
                    "-o" to "${dir.absolutePath}/clip.%(ext)s", "--no-playlist" to null,
                    "--no-warnings" to null, "--socket-timeout" to "30", "--retries" to "3",
                )
                if (c != null) opts += "--extractor-args" to "youtube:player_client=$c"
                exec("https://www.youtube.com/watch?v=$id", opts)
                findVideo(dir)?.let { return it to true }
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                last = e
                AppLog.add("   ⚠ Klip indirme (${c ?: "varsayılan"}): ${shortErr(e)}")
            }
        }
        // خطة بديلة: الفيديو كاملاً بدقة 720 ثم نقص منه محلياً
        AppLog.add("   ↪ Videoyu tamamen indirip sonra kesiyorum...")
        for (c in clients) {
            try {
                dir.listFiles()?.forEach { it.delete() }
                val opts = mutableListOf<Pair<String, String?>>(
                    "-f" to "bv*[height<=720][vcodec^=avc1]+ba[ext=m4a]/b[height<=720]/b",
                    "--merge-output-format" to "mp4", "-o" to "${dir.absolutePath}/full.%(ext)s",
                    "--no-playlist" to null, "--no-warnings" to null, "--socket-timeout" to "30", "--retries" to "3",
                )
                if (c != null) opts += "--extractor-args" to "youtube:player_client=$c"
                exec("https://www.youtube.com/watch?v=$id", opts)
                findVideo(dir)?.let { return it to false }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { last = e }
        }
        error("Klip indirilemedi: ${last?.let { shortErr(it) } ?: "bilinmiyor"}")
    }

    private fun findVideo(dir: File): File? =
        dir.listFiles { f -> f.isFile && f.length() > 10_000 && f.extension.lowercase() in setOf("mp4", "mkv", "webm", "mov") }
            ?.maxByOrNull { it.length() }
}
