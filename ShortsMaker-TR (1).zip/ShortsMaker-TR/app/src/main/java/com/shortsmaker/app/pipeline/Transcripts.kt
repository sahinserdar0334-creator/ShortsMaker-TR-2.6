package com.shortsmaker.app.pipeline

import android.util.Base64
import com.shortsmaker.app.data.AppLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.ensureActive
import java.io.File
import kotlin.coroutines.coroutineContext

/** مقطع نصي مؤقّت بالثواني. */
class Seg(val start: Double, val end: Double, val text: String)

class Transcript(val segs: List<Seg>, val lang: String) {
    val isTurkish get() = lang.startsWith("tr")
    val duration get() = segs.maxOfOrNull { it.end } ?: 0.0
}

/** يجلب نص الفيديو: من ترجمة يوتيوب إن وُجدت، وإلا بتفريغ الصوت عبر Gemini. */
object Transcripts {

    suspend fun fetch(apiKey: String, model: String, id: String, work: File): Transcript {
        val subs = Yt.subtitles(id, File(work, "subs"))
        pick(subs)?.let { (f, lang) ->
            val segs = withContext(Dispatchers.IO) { parseJson3(f) }
            if (segs.size >= 5) return Transcript(segs, lang)
        }
        AppLog.add("   ℹ Hazır altyazı yok, sesi yapay zekâ ile metne çeviriyorum...")
        return fromAudio(apiKey, model, id, work)
    }

    /** الأفضلية: عربي أصلي، ثم عربي، ثم إنجليزي أصلي، ثم إنجليزي، ثم أي ملف. */
    private fun pick(files: List<File>): Pair<File, String>? {
        if (files.isEmpty()) return null
        fun lang(f: File) = f.name.removeSuffix(".json3").substringAfterLast('.')
        val order = listOf("tr-orig", "tr", "en-orig", "en")
        for (l in order) files.firstOrNull { lang(it) == l }?.let { return it to l }
        return files.first().let { it to lang(it) }
    }

    private fun parseJson3(f: File): List<Seg> {
        val ev = JSONObject(f.readText()).optJSONArray("events") ?: return emptyList()
        val raw = mutableListOf<Seg>()
        for (i in 0 until ev.length()) {
            val e = ev.getJSONObject(i)
            val segs = e.optJSONArray("segs") ?: continue
            val sb = StringBuilder()
            for (k in 0 until segs.length()) sb.append(segs.getJSONObject(k).optString("utf8"))
            val text = sb.toString().replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
            if (text.isEmpty()) continue
            val s = e.optLong("tStartMs") / 1000.0
            val d = e.optLong("dDurationMs", 3000) / 1000.0
            raw += Seg(s, s + d, text)
        }
        // لا نسمح بتداخل المقاطع: نهاية كل مقطع لا تتجاوز بداية التالي
        return raw.mapIndexed { i, s ->
            val nextStart = raw.getOrNull(i + 1)?.start ?: s.end
            Seg(s.start, minOf(s.end, maxOf(nextStart, s.start + 0.5)), s.text)
        }
    }

    /** تفريغ الصوت على دفعات (10 دقائق لكل دفعة) وبصيغة نص مختصرة بدل JSON حتى لا ينقطع الرد. */
    private suspend fun fromAudio(apiKey: String, model: String, id: String, work: File): Transcript {
        val total = Yt.duration(id)
        val maxTotal = 3600.0 // نفرّغ حتى ساعة واحدة كحد أقصى
        val limit = if (total > 0) minOf(total, maxTotal) else 1200.0
        if (total > maxTotal) AppLog.add("   ℹ Video uzun (${(total / 60).toInt()} dk): yalnızca ilk ${(maxTotal / 60).toInt()} dakikayı çeviriyorum")
        val segs = mutableListOf<Seg>()
        var s = 0.0
        var i = 0
        while (s < limit) {
            coroutineContext.ensureActive()
            val e = minOf(s + 600.0, limit)
            val f = Yt.audioSection(id, s, e, File(work, "audio$i"))
            if (f == null) AppLog.add("   ⚠ Sesin ${i + 1}. parçası indirilemedi")
            else try {
                val part = transcribeChunk(apiKey, model, f, s)
                segs += part
                AppLog.add("   🎧 Parça ${i + 1}: ${part.size} bölüm")
            } catch (ex: kotlinx.coroutines.CancellationException) { throw ex } catch (ex: Exception) {
                AppLog.add("   ⚠ Parça ${i + 1} metne çevrilemedi: ${ex.message?.take(120)}")
            } finally { f.delete() }
            s = e; i++
        }
        if (segs.size < 3) error("Ses metne çevrilemedi (hazır altyazı yok ve çeviri başarısız)")
        return Transcript(segs.sortedBy { it.start }, "tr")
    }

    private suspend fun transcribeChunk(apiKey: String, model: String, f: File, offset: Double): List<Seg> {
        if (f.length() > 18L * 1024 * 1024) error("Ses parçası çok büyük")
        val b64 = withContext(Dispatchers.IO) { Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) }
        val mime = if (f.extension.lowercase() == "webm") "audio/webm" else "audio/mp4"
        val prompt = """
Transcribe this audio into short segments of about 3 to 8 seconds each.
Write the text in Turkish (translate to natural Turkish if the speech is in another language).
Output ONLY plain lines in exactly this format, one segment per line, with no JSON, no numbering and no other text:
START|END|TEXT
START and END are decimal seconds from the beginning of THIS audio (for example 0.0|4.2|text).
""".trimIndent()
        val out = GeminiApi.text(
            apiKey, model,
            listOf(
                GeminiApi.textPart(prompt),
                JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", b64)),
            ),
        )
        return out.lines().mapNotNull { l ->
            val p = l.trim().split('|', limit = 3)
            if (p.size < 3) return@mapNotNull null
            val a = p[0].trim().toDoubleOrNull() ?: return@mapNotNull null
            val b = p[1].trim().toDoubleOrNull() ?: return@mapNotNull null
            val t = p[2].trim()
            if (t.isEmpty() || b <= a) null else Seg(a + offset, b + offset, t)
        }
    }
}
