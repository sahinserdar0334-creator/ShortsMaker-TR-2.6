package com.shortsmaker.app.publish

import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okio.BufferedSink
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit

object Net {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.MINUTES)
        .readTimeout(10, TimeUnit.MINUTES)
        .callTimeout(0, TimeUnit.SECONDS)
        .build()

    /** ينفّذ الطلب ويعيد JSON، ويرمي خطأً واضحاً إن فشل. */
    fun json(req: okhttp3.Request): JSONObject = client.newCall(req).execute().use { r ->
        val s = r.body?.string().orEmpty()
        if (!r.isSuccessful) error("HTTP ${r.code}: ${s.take(400)}")
        if (s.isBlank()) JSONObject() else JSONObject(s)
    }
}

/** جزء من ملف (للرفع على دفعات مع تيك توك دون تحميل الملف كله في الذاكرة). */
class FileSliceBody(
    private val file: File, private val offset: Long, private val length: Long, private val type: MediaType?,
) : RequestBody() {
    override fun contentType() = type
    override fun contentLength() = length
    override fun writeTo(sink: BufferedSink) {
        RandomAccessFile(file, "r").use { raf ->
            raf.seek(offset)
            val buf = ByteArray(64 * 1024)
            var left = length
            while (left > 0) {
                val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n < 0) break
                sink.write(buf, 0, n); left -= n
            }
        }
    }
}
