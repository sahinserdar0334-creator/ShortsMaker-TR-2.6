package com.shortsmaker.app.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class StepState { PENDING, RUNNING, DONE, FAILED }
data class Step(val title: String, val state: StepState)

/** سجل مباشر + قائمة خطوات + معاينة القصة، تظهر في الواجهة أثناء العمل. */
object AppLog {
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running

    private val _steps = MutableStateFlow<List<Step>>(emptyList())
    val steps: StateFlow<List<Step>> = _steps

    /** نص القصة المكتوبة (عنوان، شخصيات، أجزاء) لعرضه للمستخدم. */
    val story = MutableStateFlow("")

    fun add(msg: String) {
        _lines.value = (_lines.value + msg).takeLast(300)
    }

    fun setRunning(v: Boolean) { _running.value = v }

    fun clear() { _lines.value = emptyList(); _steps.value = emptyList(); story.value = "" }

    /** يضيف خطوات جديدة ويعيد فهرس أولها. */
    @Synchronized
    fun addSteps(titles: List<String>): Int {
        val start = _steps.value.size
        _steps.value = _steps.value + titles.map { Step(it, StepState.PENDING) }
        return start
    }

    @Synchronized
    fun step(index: Int, state: StepState) {
        val list = _steps.value.toMutableList()
        if (index in list.indices) { list[index] = list[index].copy(state = state); _steps.value = list }
    }
}
