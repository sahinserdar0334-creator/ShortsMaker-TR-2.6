# Shorts Maker TR (Android / Kotlin)

Türkçe arayüzlü sürüm. Kanalların en yeni videolarını çeker ← Gemini en iyi anları seçer ← 9:16 klip keser ← galeriye kaydeder ← YouTube / Instagram / TikTok'ta yayınlar veya zamanlar.

- **Altyazı anahtarı:** Klipler sekmesi ▸ «Kesim» kartı ▸ «Videoya Türkçe altyazı yaz». Varsayılan: KAPALI (videoya yazı eklenmez). Açarsan Türkçe konuşmada metin aynen yazılır, başka dilde Türkçeye çevrilir.
- Paket adı `com.shortsmaker.app ile aynıdır, eski sürümün üzerine güncelleme olarak kurulur.
- APK almak: depoya yükle ▸ Actions ▸ Build APK ▸ Releases.
